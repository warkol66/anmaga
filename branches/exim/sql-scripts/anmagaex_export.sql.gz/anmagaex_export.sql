-- phpMyAdmin SQL Dump
-- version 2.11.9.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 09, 2009 at 01:20 PM
-- Server version: 5.0.67
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `anmagaex_export`
--

-- --------------------------------------------------------

--
-- Table structure for table `actionLogs_label`
--

DROP TABLE IF EXISTS `actionLogs_label`;
CREATE TABLE IF NOT EXISTS `actionLogs_label` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Id Label',
  `action` varchar(100) collate latin1_general_cs NOT NULL COMMENT 'action en que se loguea el dato',
  `label` varchar(100) collate latin1_general_cs NOT NULL COMMENT 'mensaje del log',
  `language` varchar(100) collate latin1_general_cs default NULL COMMENT 'idioma de la etiqueta',
  `forward` varchar(100) collate latin1_general_cs default NULL COMMENT 'tipo de accion de la etiqueta',
  PRIMARY KEY  (`id`,`action`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Etiquetas de logueo' AUTO_INCREMENT=17 ;

--
-- Dumping data for table `actionLogs_label`
--

INSERT INTO `actionLogs_label` (`id`, `action`, `label`, `language`, `forward`) VALUES
(1, 'backupCreate', 'Respaldo creado en el servidor con Ã©xito', 'esp', 'success'),
(2, 'backupCreate', 'Backup succesfully created on the server', 'eng', 'success'),
(3, 'backupCreate', 'Error al crear respaldo en el servidor', 'esp', 'failure'),
(4, 'backupCreate', 'Backup creation on server failed', 'eng', 'failure'),
(5, 'backupRestore', 'Respaldo restaurado desde el servidor con Ã©xito', 'esp', 'success'),
(6, 'backupRestore', 'Successfully restored backup from server', 'eng', 'success'),
(7, 'backupRestore', 'Error restaurando respaldo desde el servidor', 'esp', 'failure'),
(8, 'backupRestore', 'Backup restore from server error', 'eng', 'failure'),
(9, 'backupRestoreFromFile', 'Respaldo restaurado desde archivo con Ã©xito', 'esp', 'success'),
(10, 'backupRestoreFromFile', 'Backup successfully restored from file', 'eng', 'success'),
(11, 'backupRestoreFromFile', 'Error restaurando respaldo desde el archivo', 'esp', 'failure'),
(12, 'backupRestoreFromFile', 'Backup restore from file failed', 'eng', 'failure'),
(13, 'backupDelete', 'Backup eliminado del servidor con Ã©xito', 'esp', 'success'),
(14, 'backupDelete', 'Backup deleted successfully from server', 'eng', 'success'),
(15, 'backupDelete', 'Error al eliminar respaldo del servidor', 'esp', 'failure'),
(16, 'backupDelete', 'Backup deletion from server failed', 'eng', 'failure');

-- --------------------------------------------------------

--
-- Table structure for table `actionLogs_log`
--

DROP TABLE IF EXISTS `actionLogs_log`;
CREATE TABLE IF NOT EXISTS `actionLogs_log` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Id log',
  `userId` int(11) NOT NULL COMMENT 'Id del usuario',
  `affiliateId` int(11) NOT NULL COMMENT 'Id del afiliado',
  `datetime` datetime NOT NULL COMMENT 'Fecha en que se logueo el dato',
  `action` varchar(100) collate latin1_general_cs NOT NULL COMMENT 'action en que se logueo el dato',
  `object` varchar(100) collate latin1_general_cs NOT NULL COMMENT 'objeto sobre el cual se realizo la accion',
  `forward` varchar(100) collate latin1_general_cs default NULL COMMENT 'tipo de accion de la etiqueta',
  PRIMARY KEY  (`id`),
  KEY `actionLogs_log_FI_1` (`userId`),
  KEY `actionLogs_log_FI_2` (`action`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='logs del sistema' AUTO_INCREMENT=257 ;

--
-- Dumping data for table `actionLogs_log`
--

INSERT INTO `actionLogs_log` (`id`, `userId`, `affiliateId`, `datetime`, `action`, `object`, `forward`) VALUES
(1, 0, 0, '2009-02-20 11:41:02', 'UsersDoLogin', 'username: supervisor', 'failure'),
(2, 2, 0, '2009-02-20 11:41:19', 'UsersDoLogin', 'username: admin', 'success'),
(3, 0, 0, '2009-02-24 10:51:02', 'UsersDoLogin', 'username: supervisor', 'failure'),
(4, 1, 0, '2009-02-24 10:51:13', 'UsersDoLogin', 'username: supervisor', 'success'),
(5, 1, 0, '2009-02-25 20:38:10', 'UsersDoLogin', 'username: supervisor', 'success'),
(6, 0, 0, '2009-02-26 18:23:19', 'UsersDoLogout', 'username: supervisor', 'success'),
(7, 1, 0, '2009-02-26 18:24:14', 'UsersDoLogin', 'username: supervisor', 'success'),
(8, 1, 0, '2009-02-26 18:24:22', 'UsersDoLogin', 'username: supervisor', 'success'),
(9, 0, 0, '2009-02-26 19:13:41', 'UsersDoLogout', 'username: supervisor', 'success'),
(10, 1, 0, '2009-02-26 19:15:28', 'UsersDoLogin', 'username: supervisor', 'success'),
(11, 0, 0, '2009-02-26 19:31:27', 'UsersDoLogout', 'username: supervisor', 'success'),
(12, 1, 0, '2009-02-26 19:32:14', 'UsersDoLogin', 'username: supervisor', 'success'),
(13, 0, 0, '2009-02-26 19:51:44', 'UsersDoLogout', 'username: supervisor', 'success'),
(14, 1, 0, '2009-02-26 19:54:21', 'UsersDoLogin', 'username: supervisor', 'success'),
(15, 0, 0, '2009-02-27 00:42:06', 'UsersDoLogout', 'username: supervisor', 'success'),
(16, 1, 0, '2009-02-27 11:54:22', 'UsersLevelsDoEdit', 'name: Presidente action: create', 'success'),
(17, 1, 0, '2009-02-27 11:54:40', 'UsersLevelsDoEdit', 'name: Usuario.cn action: create', 'success'),
(18, 1, 0, '2009-02-27 13:23:15', 'BackupCreate', '', 'success'),
(19, 1, 0, '2009-02-27 13:29:43', 'BackupCreate', '', 'success'),
(20, 1, 0, '2009-02-27 13:29:52', 'BackupDelete', '', 'success'),
(21, 0, 0, '2009-03-01 23:26:39', 'BackupCreate', '', 'success'),
(22, 1, 0, '2009-03-02 13:34:11', 'UsersDoLogin', 'username: supervisor', 'success'),
(23, 1, 0, '2009-03-04 16:40:31', 'UsersDoLogin', 'username: supervisor', 'success'),
(24, 1, 0, '2009-03-04 16:41:04', 'UsersDoLogin', 'username: supervisor', 'success'),
(25, 0, 0, '2009-03-04 17:25:33', 'UsersDoLogout', 'username: supervisor', 'success'),
(26, 1, 0, '2009-03-04 17:25:39', 'UsersDoLogin', 'username: supervisor', 'success'),
(27, 0, 0, '2009-03-04 17:25:44', 'UsersDoLogout', 'username: supervisor', 'success'),
(28, 0, 0, '2009-03-04 17:25:55', 'UsersDoLogin', 'username: epa', 'failure'),
(29, 0, 0, '2009-03-04 17:26:04', 'UsersDoLogin', 'username: epa', 'failure'),
(30, 1, 0, '2009-03-04 17:27:03', 'UsersDoLogin', 'username: supervisor', 'success'),
(31, 0, 0, '2009-03-04 17:27:10', 'UsersDoLogout', 'username: supervisor', 'success'),
(32, 1, 0, '2009-03-04 22:17:12', 'UsersDoLogin', 'username: supervisor', 'success'),
(33, 0, 0, '2009-03-06 11:21:22', 'UsersDoLogout', 'username: supervisor', 'success'),
(34, 1, 0, '2009-03-06 11:21:50', 'UsersDoLogin', 'username: supervisor', 'success'),
(35, 0, 0, '2009-03-06 12:04:57', 'UsersDoLogin', 'username: epa', 'failure'),
(36, 0, 0, '2009-03-06 12:05:11', 'UsersDoLogin', 'username: EPA', 'failure'),
(37, 0, 0, '2009-03-06 12:05:19', 'UsersDoLogin', 'username: EPA', 'failure'),
(38, 1, 0, '2009-03-06 12:05:25', 'UsersDoLogin', 'username: supervisor', 'success'),
(39, 0, 0, '2009-03-06 12:05:37', 'UsersDoLogin', 'username: epa', 'failure'),
(40, 0, 0, '2009-03-06 12:06:27', 'UsersDoLogin', 'username: epa', 'failure'),
(41, 0, 0, '2009-03-06 12:06:38', 'UsersDoLogin', 'username: epa', 'failure'),
(42, 0, 0, '2009-03-06 12:06:46', 'UsersDoLogout', 'username: supervisor', 'success'),
(43, 0, 0, '2009-03-06 12:16:27', 'UsersDoLogin', 'username: epa', 'failure'),
(44, 0, 0, '2009-03-06 12:16:39', 'UsersDoLogin', 'username: epa', 'failure'),
(45, 1, 1, '2009-03-06 12:34:21', 'AffiliatesUsersDoLogin', 'username: epa', 'success'),
(46, 0, 0, '2009-03-06 12:34:36', 'UsersDoLogin', 'username: epa', 'failure'),
(47, 0, 0, '2009-03-06 12:34:48', 'UsersDoLogin', 'username: ', 'failure'),
(48, 0, 0, '2009-03-06 12:35:08', 'UsersDoLogin', 'username: ', 'failure'),
(49, 0, 0, '2009-03-06 12:35:22', 'UsersDoLogin', 'username: ', 'failure'),
(50, 1, 0, '2009-03-06 12:35:35', 'UsersDoLogin', 'username: supervisor', 'success'),
(51, 0, 0, '2009-03-06 12:35:49', 'UsersDoLogout', 'username: supervisor', 'success'),
(52, 0, 0, '2009-03-06 12:36:01', 'UsersDoLogin', 'username: ', 'failure'),
(53, 1, 1, '2009-03-06 12:42:21', 'AffiliatesUsersDoLogin', 'username: epa', 'success'),
(54, 1, 1, '2009-03-06 12:44:44', 'AffiliatesUsersDoLogin', 'username: epa', 'success'),
(55, 0, 0, '2009-03-06 12:51:20', 'UsersDoLogin', 'username: ', 'failure'),
(56, 1, 1, '2009-03-06 12:51:35', 'AffiliatesUsersDoLogin', 'username: epa', 'success'),
(57, 0, 0, '2009-03-06 12:51:51', 'UsersDoLogin', 'username: ', 'failure'),
(58, 0, 0, '2009-03-06 12:52:02', 'UsersDoLogin', 'username: ', 'failure'),
(59, 0, 0, '2009-03-06 12:52:38', 'UsersDoLogin', 'username: ', 'failure'),
(60, 1, 0, '2009-03-06 12:52:54', 'UsersDoLogin', 'username: supervisor', 'success'),
(61, 0, 0, '2009-03-06 12:53:05', 'UsersDoLogout', 'username: supervisor', 'success'),
(62, 0, 0, '2009-03-06 12:53:19', 'UsersDoLogin', 'username: ', 'failure'),
(63, 0, 0, '2009-03-06 12:54:19', 'UsersDoLogin', 'username: ', 'failure'),
(64, 0, 0, '2009-03-06 12:54:30', 'UsersDoLogin', 'username: ', 'failure'),
(65, 0, 0, '2009-03-06 12:54:42', 'UsersDoLogin', 'username: ', 'failure'),
(66, 0, 0, '2009-03-06 13:01:50', 'UsersDoLogin', 'username: ', 'failure'),
(67, 0, 0, '2009-03-06 13:01:55', 'UsersDoLogin', 'username: ', 'failure'),
(68, 0, 0, '2009-03-06 13:02:22', 'UsersDoLogin', 'username: ', 'failure'),
(69, 0, 0, '2009-03-06 13:02:27', 'UsersDoLogin', 'username: ', 'failure'),
(70, 0, 0, '2009-03-06 13:02:29', 'UsersDoLogin', 'username: ', 'failure'),
(71, 0, 0, '2009-03-06 13:02:36', 'UsersDoLogin', 'username: ', 'failure'),
(72, 1, 0, '2009-03-06 13:24:36', 'UsersDoLogin', 'username: supervisor', 'success'),
(73, 0, 0, '2009-03-06 13:45:17', 'UsersDoLogout', 'username: supervisor', 'success'),
(74, 1, 0, '2009-03-06 13:45:24', 'UsersDoLogin', 'username: supervisor', 'success'),
(75, 0, 0, '2009-03-06 13:46:14', 'UsersDoLogout', 'username: supervisor', 'success'),
(76, 1, 0, '2009-03-06 13:46:22', 'UsersDoLogin', 'username: supervisor', 'success'),
(77, 1, 0, '2009-03-06 13:46:35', 'UsersDoLogin', 'username: supervisor', 'success'),
(78, 1, 0, '2009-03-06 13:53:21', 'UsersDoLogin', 'username: supervisor', 'success'),
(79, 0, 0, '2009-03-06 15:43:40', 'UsersDoLogin', 'username: ', 'failure'),
(80, 0, 0, '2009-03-06 15:56:09', 'UsersDoLogin', 'username: ', 'failure'),
(81, 0, 0, '2009-03-06 15:56:25', 'UsersDoLogin', 'username: ', 'failure'),
(82, 0, 0, '2009-03-06 15:56:36', 'UsersDoLogin', 'username: ', 'failure'),
(83, 0, 0, '2009-03-06 15:57:16', 'UsersDoLogin', 'username: ', 'failure'),
(84, 0, 0, '2009-03-06 15:57:28', 'UsersDoLogin', 'username: ', 'failure'),
(85, 0, 0, '2009-03-06 15:57:54', 'UsersDoLogin', 'username: ', 'failure'),
(86, 0, 0, '2009-03-06 15:58:10', 'UsersDoLogin', 'username: ', 'failure'),
(87, 0, 0, '2009-03-06 15:58:20', 'UsersDoLogout', 'username: supervisor', 'success'),
(88, 0, 0, '2009-03-06 15:58:37', 'UsersDoLogin', 'username: ', 'failure'),
(89, 0, 0, '2009-03-06 15:58:44', 'UsersDoLogin', 'username: ', 'failure'),
(90, 0, 0, '2009-03-06 16:07:34', 'UsersDoLogin', 'username: ', 'failure'),
(91, 0, 0, '2009-03-06 16:07:42', 'UsersDoLogin', 'username: ', 'failure'),
(92, 0, 0, '2009-03-06 16:07:53', 'UsersDoLogin', 'username: ', 'failure'),
(93, 0, 0, '2009-03-06 16:08:30', 'UsersDoLogin', 'username: ', 'failure'),
(94, 1, 1, '2009-03-06 16:08:41', 'AffiliatesUsersDoLogin', 'username: epa', 'success'),
(95, 0, 0, '2009-03-06 16:08:55', 'UsersDoLogin', 'username: ', 'failure'),
(96, 0, 0, '2009-03-06 16:09:07', 'UsersDoLogin', 'username: ', 'failure'),
(97, 0, 0, '2009-03-06 16:15:05', 'UsersDoLogin', 'username: ', 'failure'),
(98, 0, 0, '2009-03-06 16:15:06', 'UsersDoLogin', 'username: ', 'failure'),
(99, 0, 0, '2009-03-06 16:15:06', 'UsersDoLogin', 'username: ', 'failure'),
(100, 0, 0, '2009-03-06 16:15:17', 'UsersDoLogin', 'username: ', 'failure'),
(101, 0, 0, '2009-03-06 16:15:33', 'UsersDoLogin', 'username: ', 'failure'),
(102, 0, 0, '2009-03-06 16:15:41', 'UsersDoLogin', 'username: ', 'failure'),
(103, 0, 0, '2009-03-06 16:21:28', 'UsersDoLogin', 'username: ', 'failure'),
(104, 0, 0, '2009-03-06 16:25:08', 'UsersDoLogin', 'username: ', 'failure'),
(105, 0, 0, '2009-03-06 16:25:35', 'UsersDoLogin', 'username: ', 'failure'),
(106, 0, 0, '2009-03-06 16:25:49', 'UsersDoLogin', 'username: ', 'failure'),
(107, 0, 0, '2009-03-06 16:26:16', 'UsersDoLogin', 'username: ', 'failure'),
(108, 0, 0, '2009-03-06 16:26:28', 'UsersDoLogin', 'username: ', 'failure'),
(109, 0, 0, '2009-03-06 16:26:38', 'UsersDoLogin', 'username: ', 'failure'),
(110, 0, 0, '2009-03-06 16:28:08', 'UsersDoLogin', 'username: ', 'failure'),
(111, 0, 0, '2009-03-06 16:28:15', 'UsersDoLogin', 'username: ', 'failure'),
(112, 0, 0, '2009-03-06 16:28:21', 'UsersDoLogin', 'username: ', 'failure'),
(113, 0, 0, '2009-03-06 16:28:34', 'UsersDoLogin', 'username: ', 'failure'),
(114, 0, 0, '2009-03-06 16:28:43', 'UsersDoLogin', 'username: ', 'failure'),
(115, 0, 0, '2009-03-06 16:32:05', 'UsersDoLogin', 'username: ', 'failure'),
(116, 0, 0, '2009-03-06 16:32:50', 'UsersDoLogin', 'username: ', 'failure'),
(117, 0, 0, '2009-03-06 16:32:57', 'UsersDoLogin', 'username: ', 'failure'),
(118, 0, 0, '2009-03-06 16:33:03', 'UsersDoLogin', 'username: ', 'failure'),
(119, 0, 0, '2009-03-06 16:36:58', 'UsersDoLogin', 'username: ', 'failure'),
(120, 0, 0, '2009-03-06 16:37:06', 'UsersDoLogin', 'username: ', 'failure'),
(121, 0, 0, '2009-03-06 16:37:13', 'UsersDoLogin', 'username: ', 'failure'),
(122, 0, 0, '2009-03-06 16:37:23', 'UsersDoLogin', 'username: ', 'failure'),
(123, 0, 0, '2009-03-06 16:38:46', 'UsersDoLogin', 'username: ', 'failure'),
(124, 0, 0, '2009-03-06 16:39:00', 'UsersDoLogin', 'username: ', 'failure'),
(125, 0, 0, '2009-03-06 16:39:38', 'UsersDoLogin', 'username: ', 'failure'),
(126, 0, 0, '2009-03-06 16:41:37', 'UsersDoLogin', 'username: ', 'failure'),
(127, 1, 1, '2009-03-06 16:42:01', 'AffiliatesUsersDoLogin', 'username: epa', 'success'),
(128, 0, 0, '2009-03-06 16:42:28', 'UsersDoLogin', 'username: ', 'failure'),
(129, 1, 1, '2009-03-06 16:42:35', 'AffiliatesUsersDoLogin', 'username: epa', 'success'),
(130, 1, 0, '2009-03-06 16:44:02', 'UsersDoLogin', 'username: supervisor', 'success'),
(131, 0, 0, '2009-03-06 16:44:32', 'UsersDoLogout', 'username: supervisor', 'success'),
(132, 1, 0, '2009-03-06 16:44:39', 'UsersDoLogin', 'username: supervisor', 'success'),
(133, 0, 0, '2009-03-06 16:44:45', 'UsersDoLogout', 'username: supervisor', 'success'),
(134, 1, 1, '2009-03-06 16:44:55', 'AffiliatesUsersDoLogin', 'username: epa', 'success'),
(135, 1, 1, '2009-03-06 16:45:23', 'AffiliatesUsersDoLogin', 'username: epa', 'success'),
(136, 1, 1, '2009-03-06 16:45:37', 'AffiliatesUsersDoLogin', 'username: epa', 'success'),
(137, 1, 1, '2009-03-06 16:52:24', 'AffiliatesUsersDoLogin', 'username: epa', 'success'),
(138, 1, 1, '2009-03-06 16:54:26', 'AffiliatesUsersDoLogin', 'username: epa', 'success'),
(139, 0, 0, '2009-03-06 16:54:40', 'UsersDoLogin', 'username: ', 'failure'),
(140, 0, 0, '2009-03-06 16:54:48', 'UsersDoLogin', 'username: ', 'failure'),
(141, 1, 1, '2009-03-06 16:55:08', 'AffiliatesUsersDoLogin', 'username: epa', 'success'),
(142, 1, 1, '2009-03-06 16:55:18', 'AffiliatesUsersDoLogin', 'username: epa', 'success'),
(143, 1, 0, '2009-03-06 16:55:31', 'UsersDoLogin', 'username: supervisor', 'success'),
(144, 0, 0, '2009-03-06 16:55:38', 'UsersDoLogout', 'username: supervisor', 'success'),
(145, 1, 1, '2009-03-06 16:55:50', 'AffiliatesUsersDoLogin', 'username: epa', 'success'),
(146, 1, 1, '2009-03-06 16:56:28', 'AffiliatesUsersDoLogin', 'username: epa', 'success'),
(147, 1, 0, '2009-03-06 16:56:47', 'UsersDoLogin', 'username: supervisor', 'success'),
(148, 0, 0, '2009-03-06 16:56:52', 'UsersDoLogout', 'username: supervisor', 'success'),
(149, 1, 0, '2009-03-06 17:37:03', 'UsersDoLogin', 'username: supervisor', 'success'),
(150, 0, 0, '2009-03-06 17:51:21', 'UsersDoLogout', 'username: supervisor', 'success'),
(151, 1, 1, '2009-03-06 17:51:31', 'AffiliatesUsersDoLogin', 'username: epa', 'success'),
(152, 1, 0, '2009-03-06 17:51:50', 'UsersDoLogin', 'username: supervisor', 'success'),
(153, 1, 0, '2009-03-06 19:17:34', 'UsersDoLogin', 'username: supervisor', 'success'),
(154, 1, 0, '2009-03-07 11:59:51', 'UsersDoLogin', 'username: supervisor', 'success'),
(155, 0, 0, '2009-03-07 23:00:10', 'BackupCreate', '', 'success'),
(156, 0, 0, '2009-03-07 23:07:02', 'BackupCreate', '', 'success'),
(157, 1, 0, '2009-03-08 00:35:11', 'BackupDelete', '', 'success'),
(158, 1, 0, '2009-03-09 14:45:05', 'UsersDoLogin', 'username: supervisor', 'success'),
(159, 1, 0, '2009-03-09 22:41:07', 'UsersDoLogin', 'username: supervisor', 'success'),
(160, 1, 0, '2009-03-11 12:01:50', 'UsersDoLogin', 'username: supervisor', 'success'),
(161, 1, 0, '2009-03-12 14:06:54', 'UsersDoLogin', 'username: supervisor', 'success'),
(162, 1, 0, '2009-03-12 16:22:41', 'UsersDoLogin', 'username: supervisor', 'success'),
(163, 0, 0, '2009-03-12 16:28:59', 'UsersDoLogout', 'username: supervisor', 'success'),
(164, 1, 0, '2009-03-12 16:29:25', 'UsersDoLogin', 'username: supervisor', 'success'),
(165, 0, 0, '2009-03-12 19:51:10', 'UsersDoLogout', 'username: supervisor', 'success'),
(166, 1, 0, '2009-03-12 19:51:19', 'UsersDoLogin', 'username: supervisor', 'success'),
(167, 0, 0, '2009-03-12 21:47:24', 'UsersDoLogout', 'username: supervisor', 'success'),
(168, 1, 0, '2009-03-13 13:14:52', 'UsersDoLogin', 'username: supervisor', 'success'),
(169, 0, 0, '2009-03-14 01:21:24', 'UsersDoLogout', 'username: supervisor', 'success'),
(170, 0, 0, '2009-03-14 22:00:10', 'BackupCreate', '', 'success'),
(171, 1, 0, '2009-03-17 17:05:56', 'UsersDoLogin', 'username: supervisor', 'success'),
(172, 0, 0, '2009-03-17 17:28:59', 'UsersDoLogout', 'username: supervisor', 'success'),
(173, 1, 0, '2009-03-17 18:02:56', 'BackupCreate', '', 'success'),
(174, 1, 0, '2009-03-17 18:03:06', 'BackupDelete', '', 'success'),
(175, 1, 0, '2009-03-17 18:04:48', 'BackupCreate', '', 'success'),
(176, 1, 0, '2009-03-17 19:33:21', 'BackupCreate', '', 'success'),
(177, 1, 0, '2009-03-17 19:34:24', 'BackupDelete', '', 'success'),
(178, 1, 0, '2009-03-17 19:58:24', 'UsersDoLogin', 'username: supervisor', 'success'),
(179, 1, 0, '2009-03-17 20:13:03', 'UsersDoLogin', 'username: supervisor', 'success'),
(180, 0, 0, '2009-03-17 20:14:28', 'UsersDoLogout', 'username: supervisor', 'success'),
(181, 1, 0, '2009-03-17 20:15:41', 'UsersDoLogin', 'username: supervisor', 'success'),
(182, 0, 0, '2009-03-17 22:42:33', 'UsersDoLogout', 'username: supervisor', 'success'),
(183, 1, 0, '2009-03-17 23:03:10', 'UsersDoLogin', 'username: supervisor', 'success'),
(184, 0, 0, '2009-03-18 01:10:30', 'UsersDoLogout', 'username: supervisor', 'success'),
(185, 1, 0, '2009-03-18 15:56:00', 'UsersDoLogin', 'username: supervisor', 'success'),
(186, 1, 0, '2009-03-18 16:22:21', 'UsersDoLogin', 'username: supervisor', 'success'),
(187, 0, 0, '2009-03-18 16:26:21', 'UsersDoLogout', 'username: supervisor', 'success'),
(188, 1, 0, '2009-03-18 20:29:46', 'UsersDoLogin', 'username: supervisor', 'success'),
(189, 1, 0, '2009-03-18 22:34:42', 'UsersDoLogin', 'username: supervisor', 'success'),
(190, 1, 0, '2009-03-20 18:07:29', 'UsersDoLogin', 'username: supervisor', 'success'),
(191, 1, 0, '2009-03-20 18:50:12', 'UsersDoLogin', 'username: supervisor', 'success'),
(192, 0, 0, '2009-03-21 22:00:09', 'BackupCreate', '', 'success'),
(193, 1, 0, '2009-03-24 20:55:51', 'UsersDoLogin', 'username: supervisor', 'success'),
(194, 1, 0, '2009-03-24 21:09:48', 'UsersDoLogin', 'username: supervisor', 'success'),
(195, 1, 0, '2009-03-27 11:00:32', 'UsersDoLogin', 'username: supervisor', 'success'),
(196, 1, 0, '2009-03-27 16:48:36', 'UsersDoLogin', 'username: supervisor', 'success'),
(197, 0, 0, '2009-03-27 16:55:34', 'UsersDoLogin', 'username: supervisor', 'failure'),
(198, 1, 1, '2009-03-27 16:55:43', 'AffiliatesUsersDoLogin', 'username: epa', 'success'),
(199, 0, 0, '2009-03-28 22:00:11', 'BackupCreate', '', 'success'),
(200, 2, 0, '2009-03-30 12:12:02', 'UsersDoLogin', 'username: admin', 'success'),
(201, 1, 0, '2009-03-30 19:04:21', 'UsersDoLogin', 'username: supervisor', 'success'),
(202, 1, 0, '2009-04-02 15:42:15', 'UsersDoLogin', 'username: supervisor', 'success'),
(203, 1, 0, '2009-04-03 16:35:42', 'UsersDoLogin', 'username: supervisor', 'success'),
(204, 1, 0, '2009-04-03 16:37:56', 'UsersDoLogin', 'username: supervisor', 'success'),
(205, 0, 0, '2009-04-03 16:38:35', 'UsersDoLogin', 'username: supervisor', 'failure'),
(206, 1, 0, '2009-04-03 16:38:44', 'UsersDoLogin', 'username: supervisor', 'success'),
(207, 0, 0, '2009-04-04 22:00:14', 'BackupCreate', '', 'success'),
(208, 1, 0, '2009-04-10 21:34:01', 'UsersDoLogin', 'username: supervisor', 'success'),
(209, 0, 0, '2009-04-11 22:00:16', 'BackupCreate', '', 'success'),
(210, 0, 0, '2009-04-13 18:57:04', 'UsersDoLogin', 'username: supervisor', 'failure'),
(211, 0, 0, '2009-04-13 18:57:19', 'UsersDoLogin', 'username: supervisor', 'failure'),
(212, 0, 0, '2009-04-13 18:57:28', 'UsersDoLogin', 'username: supervisor', 'failure'),
(213, 2, 0, '2009-04-13 18:57:36', 'UsersDoLogin', 'username: admin', 'success'),
(214, 1, 0, '2009-04-17 14:55:28', 'UsersDoLogin', 'username: supervisor', 'success'),
(215, 2, 0, '2009-04-17 17:18:08', 'UsersDoLogin', 'username: admin', 'success'),
(216, 0, 0, '2009-04-18 22:00:13', 'BackupCreate', '', 'success'),
(217, 1, 0, '2009-04-20 13:02:21', 'UsersDoLogin', 'username: supervisor', 'success'),
(218, 1, 0, '2009-04-20 17:38:50', 'UsersDoLogin', 'username: supervisor', 'success'),
(219, 1, 0, '2009-04-21 13:59:35', 'UsersDoLogin', 'username: supervisor', 'success'),
(220, 1, 0, '2009-04-22 15:45:29', 'UsersDoLogin', 'username: supervisor', 'success'),
(221, 0, 0, '2009-04-25 22:00:14', 'BackupCreate', '', 'success'),
(222, 1, 0, '2009-04-27 18:44:18', 'UsersDoLogin', 'username: supervisor', 'success'),
(223, 0, 0, '2009-04-27 19:07:22', 'UsersDoLogout', 'username: supervisor', 'success'),
(224, 1, 0, '2009-04-27 19:07:29', 'UsersDoLogin', 'username: supervisor', 'success'),
(225, 1, 0, '2009-04-27 19:13:42', 'UsersDoLogin', 'username: supervisor', 'success'),
(226, 1, 0, '2009-04-28 16:55:27', 'UsersDoLogin', 'username: supervisor', 'success'),
(227, 1, 0, '2009-04-28 21:15:49', 'UsersDoLogin', 'username: supervisor', 'success'),
(228, 1, 0, '2009-04-29 23:06:28', 'UsersDoLogin', 'username: supervisor', 'success'),
(229, 0, 0, '2009-04-30 00:04:20', 'UsersDoLogout', 'username: supervisor', 'success'),
(230, 1, 0, '2009-05-01 13:47:48', 'UsersDoLogin', 'username: supervisor', 'success'),
(231, 0, 0, '2009-05-02 22:00:20', 'BackupCreate', '', 'success'),
(232, 1, 0, '2009-05-04 15:25:46', 'UsersDoLogin', 'username: supervisor', 'success'),
(233, 1, 0, '2009-05-04 16:52:55', 'UsersDoLogin', 'username: supervisor', 'success'),
(234, 0, 0, '2009-05-04 18:04:20', 'UsersDoLogout', 'username: supervisor', 'success'),
(235, 1, 0, '2009-05-04 18:41:48', 'UsersDoLogin', 'username: supervisor', 'success'),
(236, 1, 0, '2009-05-04 22:28:19', 'UsersDoLogin', 'username: supervisor', 'success'),
(237, 1, 0, '2009-05-05 00:53:49', 'BackupCreate', '', 'success'),
(238, 1, 0, '2009-05-05 00:55:08', 'BackupCreate', '', 'success'),
(239, 1, 0, '2009-05-05 00:55:28', 'BackupCreate', '', 'success'),
(240, 1, 0, '2009-05-05 00:56:38', 'BackupDelete', '', 'success'),
(241, 1, 0, '2009-05-05 00:56:49', 'BackupDelete', '', 'success'),
(242, 1, 0, '2009-05-05 00:56:58', 'BackupDelete', '', 'success'),
(243, 1, 0, '2009-05-05 00:57:07', 'BackupDelete', '', 'success'),
(244, 1, 0, '2009-05-05 00:57:17', 'BackupDelete', '', 'success'),
(245, 1, 0, '2009-05-05 00:57:38', 'BackupDelete', '', 'success'),
(246, 1, 0, '2009-05-07 19:35:34', 'UsersDoLogin', 'username: supervisor', 'success'),
(247, 1, 0, '2009-05-07 19:46:34', 'UsersDoLogin', 'username: supervisor', 'success'),
(248, 0, 0, '2009-05-07 19:57:51', 'UsersDoLogout', 'username: supervisor', 'success'),
(249, 1, 0, '2009-05-08 13:45:43', 'UsersDoLogin', 'username: supervisor', 'success'),
(250, 1, 0, '2009-05-08 16:06:26', 'UsersDoLogin', 'username: supervisor', 'success'),
(251, 1, 0, '2009-05-08 20:23:53', 'UsersDoLogin', 'username: supervisor', 'success'),
(252, 0, 0, '2009-05-08 21:15:40', 'UsersDoLogout', 'username: supervisor', 'success'),
(253, 1, 1, '2009-05-08 21:15:50', 'AffiliatesUsersDoLogin', 'username: epa', 'success'),
(254, 1, 0, '2009-05-08 21:19:34', 'UsersDoLogin', 'username: supervisor', 'success'),
(255, 1, 0, '2009-05-08 21:21:44', 'UsersDoLogin', 'username: supervisor', 'success'),
(256, 1, 1, '2009-05-08 21:22:38', 'AffiliatesUsersDoLogin', 'username: epa', 'success');

-- --------------------------------------------------------

--
-- Table structure for table `affiliates_affiliate`
--

DROP TABLE IF EXISTS `affiliates_affiliate`;
CREATE TABLE IF NOT EXISTS `affiliates_affiliate` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Id afiliado',
  `name` varchar(255) collate latin1_general_cs NOT NULL COMMENT 'nombre afiliado',
  `ownerId` int(11) default NULL COMMENT 'Id del usuario administrador del afiliado',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `affiliates_affiliate_U_1` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Afiliados' AUTO_INCREMENT=3 ;

--
-- Dumping data for table `affiliates_affiliate`
--

INSERT INTO `affiliates_affiliate` (`id`, `name`, `ownerId`) VALUES
(1, 'EPA', 1),
(2, 'Anmaga', 2);

-- --------------------------------------------------------

--
-- Table structure for table `affiliates_affiliateInfo`
--

DROP TABLE IF EXISTS `affiliates_affiliateInfo`;
CREATE TABLE IF NOT EXISTS `affiliates_affiliateInfo` (
  `affiliateId` int(11) NOT NULL COMMENT 'Id afiliado',
  `affiliateInternalNumber` int(11) NOT NULL COMMENT 'Id interno',
  `address` varchar(255) collate latin1_general_cs default NULL COMMENT 'Direccion afiliado',
  `phone` varchar(50) collate latin1_general_cs default NULL COMMENT 'Telefono afiliado',
  `email` varchar(50) collate latin1_general_cs default NULL COMMENT 'Email afiliado',
  `contact` varchar(50) collate latin1_general_cs default NULL COMMENT 'Nombre de persona de contacto',
  `contactEmail` varchar(100) collate latin1_general_cs default NULL COMMENT 'Email de persona de contacto',
  `web` varchar(255) collate latin1_general_cs default NULL COMMENT 'Direccion web del afiliado',
  `memo` text collate latin1_general_cs COMMENT 'Informacion adicional del afiliado',
  PRIMARY KEY  (`affiliateId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Informacion del afiliado';

--
-- Dumping data for table `affiliates_affiliateInfo`
--

INSERT INTO `affiliates_affiliateInfo` (`affiliateId`, `affiliateInternalNumber`, `address`, `phone`, `email`, `contact`, `contactEmail`, `web`, `memo`) VALUES
(1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(2, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `affiliates_branch`
--

DROP TABLE IF EXISTS `affiliates_branch`;
CREATE TABLE IF NOT EXISTS `affiliates_branch` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Id de la sucursal',
  `affiliateId` int(11) NOT NULL COMMENT 'Id del afiliado',
  `number` int(11) NOT NULL COMMENT 'Numero de la sucursal',
  `code` varchar(20) collate latin1_general_cs default NULL COMMENT 'Codigo de la sucursal',
  `name` varchar(255) collate latin1_general_cs default NULL COMMENT 'Nombre de la sucursal',
  `phone` varchar(100) collate latin1_general_cs default NULL COMMENT 'Telefono de la sucursal',
  `contact` varchar(50) collate latin1_general_cs default NULL COMMENT 'Nombre de persona de contacto',
  `contactEmail` varchar(100) collate latin1_general_cs default NULL COMMENT 'Email de persona de contacto',
  `memo` text collate latin1_general_cs COMMENT 'Informacion adicional de la sucursal',
  PRIMARY KEY  (`id`),
  KEY `affiliates_branch_FI_1` (`affiliateId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Affiliates branches information' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `affiliates_branch`
--


-- --------------------------------------------------------

--
-- Table structure for table `affiliates_group`
--

DROP TABLE IF EXISTS `affiliates_group`;
CREATE TABLE IF NOT EXISTS `affiliates_group` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Group ID',
  `name` varchar(255) collate latin1_general_cs NOT NULL COMMENT 'Group Name',
  `created` datetime NOT NULL COMMENT 'Creation date for',
  `updated` datetime NOT NULL COMMENT 'Last update date',
  `bitLevel` int(11) default NULL COMMENT 'Nivel',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `affiliates_group_U_1` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Groups' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `affiliates_group`
--


-- --------------------------------------------------------

--
-- Table structure for table `affiliates_groupCategory`
--

DROP TABLE IF EXISTS `affiliates_groupCategory`;
CREATE TABLE IF NOT EXISTS `affiliates_groupCategory` (
  `groupId` int(11) NOT NULL COMMENT 'Group ID',
  `categoryId` int(11) NOT NULL COMMENT 'Category ID',
  PRIMARY KEY  (`groupId`,`categoryId`),
  KEY `affiliates_groupCategory_FI_2` (`categoryId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Groups / Categories';

--
-- Dumping data for table `affiliates_groupCategory`
--


-- --------------------------------------------------------

--
-- Table structure for table `affiliates_level`
--

DROP TABLE IF EXISTS `affiliates_level`;
CREATE TABLE IF NOT EXISTS `affiliates_level` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Level ID',
  `name` varchar(255) collate latin1_general_cs NOT NULL COMMENT 'Level Name',
  `bitLevel` int(11) default NULL COMMENT 'Bit del nivel',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `affiliates_level_U_1` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Levels' AUTO_INCREMENT=3 ;

--
-- Dumping data for table `affiliates_level`
--

INSERT INTO `affiliates_level` (`id`, `name`, `bitLevel`) VALUES
(1, 'Administrador', 1),
(2, 'Usuario', 2);

-- --------------------------------------------------------

--
-- Table structure for table `affiliates_user`
--

DROP TABLE IF EXISTS `affiliates_user`;
CREATE TABLE IF NOT EXISTS `affiliates_user` (
  `id` int(11) NOT NULL auto_increment COMMENT 'User Id',
  `affiliateId` int(11) NOT NULL COMMENT 'Id afiliado',
  `username` varchar(255) collate latin1_general_cs NOT NULL COMMENT 'username',
  `password` varchar(255) collate latin1_general_cs NOT NULL COMMENT 'password',
  `active` tinyint(4) NOT NULL COMMENT 'Is user active?',
  `created` datetime NOT NULL COMMENT 'Creation date for',
  `updated` datetime NOT NULL COMMENT 'Last update date',
  `timezone` varchar(100) collate latin1_general_cs default NULL COMMENT 'Timezone GMT del usuario afiliado',
  `levelId` int(11) default NULL COMMENT 'User Level',
  `lastLogin` datetime default NULL COMMENT 'Fecha del ultimo login del usuario',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `affiliates_user_U_1` (`username`),
  KEY `affiliates_user_FI_1` (`levelId`),
  KEY `affiliates_user_FI_2` (`affiliateId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Usuarios de afiliado' AUTO_INCREMENT=3 ;

--
-- Dumping data for table `affiliates_user`
--

INSERT INTO `affiliates_user` (`id`, `affiliateId`, `username`, `password`, `active`, `created`, `updated`, `timezone`, `levelId`, `lastLogin`) VALUES
(1, 1, 'epa', 'f156508e425e0d8bad9f5e830e442a87', 1, '2009-02-12 19:45:45', '2009-03-17 14:56:51', '', 0, '2009-05-08 21:22:38'),
(2, 2, 'Julio Cesar', '3a1bc18c631b2a526cfc2b26ce005593', 1, '2009-03-04 16:48:30', '2009-03-04 16:48:30', '', 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `affiliates_userGroup`
--

DROP TABLE IF EXISTS `affiliates_userGroup`;
CREATE TABLE IF NOT EXISTS `affiliates_userGroup` (
  `userId` int(11) NOT NULL COMMENT 'Group ID',
  `groupId` int(11) NOT NULL COMMENT 'Group ID',
  PRIMARY KEY  (`userId`,`groupId`),
  KEY `affiliates_userGroup_FI_2` (`groupId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Users / Groups';

--
-- Dumping data for table `affiliates_userGroup`
--


-- --------------------------------------------------------

--
-- Table structure for table `affiliates_userInfo`
--

DROP TABLE IF EXISTS `affiliates_userInfo`;
CREATE TABLE IF NOT EXISTS `affiliates_userInfo` (
  `userId` int(11) NOT NULL COMMENT 'User Id',
  `name` varchar(255) collate latin1_general_cs default NULL COMMENT 'name',
  `surname` varchar(255) collate latin1_general_cs default NULL COMMENT 'surname',
  `mailAddress` varchar(255) collate latin1_general_cs default NULL COMMENT 'Email',
  PRIMARY KEY  (`userId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Information about users by affiliates';

--
-- Dumping data for table `affiliates_userInfo`
--

INSERT INTO `affiliates_userInfo` (`userId`, `name`, `surname`, `mailAddress`) VALUES
(1, 'Emilio', 'Perez Alvez', 'epa@epa.com.ve'),
(2, '', '', 'jcalfonzo@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `categories_category`
--

DROP TABLE IF EXISTS `categories_category`;
CREATE TABLE IF NOT EXISTS `categories_category` (
  `id` int(11) NOT NULL auto_increment,
  `parentId` int(11) NOT NULL default '0' COMMENT 'Parent Category if it has',
  `name` varchar(255) collate latin1_general_cs NOT NULL COMMENT 'Category name',
  `module` varchar(255) collate latin1_general_cs default '' COMMENT 'Module name if it is for a module',
  `active` tinyint(4) NOT NULL COMMENT 'Is category active?',
  `isPublic` tinyint(4) NOT NULL default '0' COMMENT 'Is category public?',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Categorias' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `categories_category`
--


-- --------------------------------------------------------

--
-- Table structure for table `import_bankAccount`
--

DROP TABLE IF EXISTS `import_bankAccount`;
CREATE TABLE IF NOT EXISTS `import_bankAccount` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Id',
  `accountNumber` varchar(255) collate latin1_general_cs NOT NULL COMMENT 'Numero de cuenta bancaria',
  `bank` varchar(255) collate latin1_general_cs NOT NULL COMMENT 'Banco',
  `active` tinyint(4) NOT NULL COMMENT 'Is account active?',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Cuentas bancarias' AUTO_INCREMENT=3 ;

--
-- Dumping data for table `import_bankAccount`
--

INSERT INTO `import_bankAccount` (`id`, `accountNumber`, `bank`, `active`) VALUES
(1, '05-56889-12', 'Bank of America', 1),
(2, '33-45-65569', 'Banco Internacional De Exportaciones', 1);

-- --------------------------------------------------------

--
-- Table structure for table `import_clientPurchaseOrder`
--

DROP TABLE IF EXISTS `import_clientPurchaseOrder`;
CREATE TABLE IF NOT EXISTS `import_clientPurchaseOrder` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Id de Orden de Pedido de Cliente',
  `createdAt` datetime NOT NULL COMMENT 'Creation date for',
  `status` int(11) NOT NULL COMMENT 'Status de Cotizacion',
  `timestampStatus` datetime default NULL COMMENT 'Fecha del ultimo cambio de status',
  `clientQuoteId` int(11) NOT NULL COMMENT 'id de cotizacion de proveedor relacionada',
  `affiliateId` int(11) NOT NULL COMMENT 'Afiliado',
  `affiliateUserId` int(11) default NULL COMMENT 'usuario del afiliado si creo la cotizacion',
  `userId` int(11) default NULL COMMENT 'Usuario de anmaga si creo la cotizacion',
  PRIMARY KEY  (`id`),
  KEY `import_clientPurchaseOrder_FI_1` (`clientQuoteId`),
  KEY `import_clientPurchaseOrder_FI_2` (`userId`),
  KEY `import_clientPurchaseOrder_FI_3` (`affiliateId`),
  KEY `import_clientPurchaseOrder_FI_4` (`affiliateUserId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Orden de Pedido a Cliente' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `import_clientPurchaseOrder`
--

INSERT INTO `import_clientPurchaseOrder` (`id`, `createdAt`, `status`, `timestampStatus`, `clientQuoteId`, `affiliateId`, `affiliateUserId`, `userId`) VALUES
(1, '2009-03-27 16:56:15', 1, NULL, 5, 1, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `import_clientPurchaseOrderHistory`
--

DROP TABLE IF EXISTS `import_clientPurchaseOrderHistory`;
CREATE TABLE IF NOT EXISTS `import_clientPurchaseOrderHistory` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Id',
  `clientPurchaseOrderId` int(11) NOT NULL COMMENT 'Id de orden de pedido a proveedor',
  `status` int(11) NOT NULL COMMENT 'Codigo del estado guardado.',
  `createdAt` datetime NOT NULL COMMENT 'Creation date for',
  PRIMARY KEY  (`id`),
  KEY `import_clientPurchaseOrderHistory_FI_1` (`clientPurchaseOrderId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Historial de Estados por los que fue pasando la Orden de Ped' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `import_clientPurchaseOrderHistory`
--

INSERT INTO `import_clientPurchaseOrderHistory` (`id`, `clientPurchaseOrderId`, `status`, `createdAt`) VALUES
(1, 1, 1, '2009-03-27 16:56:15');

-- --------------------------------------------------------

--
-- Table structure for table `import_clientPurchaseOrderItem`
--

DROP TABLE IF EXISTS `import_clientPurchaseOrderItem`;
CREATE TABLE IF NOT EXISTS `import_clientPurchaseOrderItem` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Id elemento de Orden de Pedido a Cliente',
  `productId` int(11) NOT NULL COMMENT 'Id producto',
  `clientPurchaseOrderId` int(11) NOT NULL COMMENT 'Id producto',
  `quantity` int(11) default NULL COMMENT 'Id producto',
  `price` float default NULL COMMENT 'precio de producto',
  PRIMARY KEY  (`id`),
  KEY `import_clientPurchaseOrderItem_FI_1` (`productId`),
  KEY `import_clientPurchaseOrderItem_FI_2` (`clientPurchaseOrderId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Elemento de Orden de Pedido a Cliente' AUTO_INCREMENT=3 ;

--
-- Dumping data for table `import_clientPurchaseOrderItem`
--

INSERT INTO `import_clientPurchaseOrderItem` (`id`, `productId`, `clientPurchaseOrderId`, `quantity`, `price`) VALUES
(1, 1, 1, 600, 3),
(2, 2, 1, 800, 30);

-- --------------------------------------------------------

--
-- Table structure for table `import_clientQuote`
--

DROP TABLE IF EXISTS `import_clientQuote`;
CREATE TABLE IF NOT EXISTS `import_clientQuote` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Id de cotizacion de cliente',
  `createdAt` datetime NOT NULL COMMENT 'Creation date for',
  `affiliateId` int(11) NOT NULL COMMENT 'Afiliado',
  `affiliateUserId` int(11) default NULL COMMENT 'usuario del afiliado si creo la cotizacion',
  `userId` int(11) default NULL COMMENT 'Usuario de anmaga si creo la cotizacion',
  `status` int(11) NOT NULL COMMENT 'Status de Cotizacion',
  `timestampStatus` datetime default NULL COMMENT 'Fecha del ultimo cambio de status',
  PRIMARY KEY  (`id`),
  KEY `import_clientQuote_FI_1` (`userId`),
  KEY `import_clientQuote_FI_2` (`affiliateId`),
  KEY `import_clientQuote_FI_3` (`affiliateUserId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Cotizacion a Cliente' AUTO_INCREMENT=30 ;

--
-- Dumping data for table `import_clientQuote`
--

INSERT INTO `import_clientQuote` (`id`, `createdAt`, `affiliateId`, `affiliateUserId`, `userId`, `status`, `timestampStatus`) VALUES
(1, '2009-02-12 07:02:01', 1, NULL, 1, 2, NULL),
(2, '2009-02-13 06:02:24', 1, NULL, 1, 2, NULL),
(3, '2009-02-13 07:02:02', 1, NULL, 1, 2, NULL),
(4, '2009-02-13 07:02:50', 1, NULL, 1, 2, NULL),
(5, '2009-02-20 11:54:01', 1, NULL, 1, 6, NULL),
(6, '2009-02-26 18:33:55', 1, NULL, 1, 2, NULL),
(7, '2009-02-26 18:34:43', 1, NULL, 1, 2, NULL),
(8, '2009-02-26 19:34:13', 1, NULL, 1, 2, NULL),
(9, '2009-02-26 19:48:52', 1, NULL, 1, 3, NULL),
(10, '2009-02-26 22:35:03', 2, NULL, 1, 1, NULL),
(11, '2009-03-04 16:52:30', 2, NULL, 2, 2, NULL),
(12, '2009-03-06 11:03:11', 2, NULL, 2, 3, NULL),
(13, '2009-03-06 19:28:35', 2, NULL, 1, 2, NULL),
(14, '2009-03-09 14:48:55', 1, NULL, 1, 2, NULL),
(15, '2009-03-17 17:25:43', 1, NULL, 1, 2, NULL),
(16, '2009-03-17 17:26:26', 1, NULL, 1, 2, NULL),
(17, '2009-03-17 17:28:01', 2, NULL, 1, 3, NULL),
(18, '2009-03-17 20:25:50', 2, NULL, 1, 1, NULL),
(19, '2009-03-17 20:37:25', 2, NULL, 1, 1, NULL),
(20, '2009-03-17 21:11:31', 1, NULL, 1, 1, NULL),
(21, '2009-03-17 23:49:09', 1, NULL, 1, 2, NULL),
(22, '2009-03-18 00:14:52', 2, NULL, 1, 2, NULL),
(23, '2009-03-27 17:11:34', 1, NULL, 1, 3, NULL),
(24, '2009-04-17 18:14:31', 1, NULL, 1, 2, NULL),
(25, '2009-04-17 22:00:14', 1, NULL, 1, 3, NULL),
(26, '2009-05-01 14:27:26', 2, NULL, 1, 1, NULL),
(27, '2009-05-01 14:36:23', 2, NULL, 1, 2, NULL),
(28, '2009-05-01 14:50:47', 2, NULL, 1, 2, NULL),
(29, '2009-05-08 13:55:38', 2, NULL, 1, 2, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `import_clientQuoteHistory`
--

DROP TABLE IF EXISTS `import_clientQuoteHistory`;
CREATE TABLE IF NOT EXISTS `import_clientQuoteHistory` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Id',
  `clientQuoteId` int(11) NOT NULL COMMENT 'Id de la cotizacion de cliente',
  `status` int(11) NOT NULL COMMENT 'Status de Cotizacion',
  `createdAt` datetime default NULL COMMENT 'Fecha del cambio de status',
  PRIMARY KEY  (`id`),
  KEY `import_clientQuoteHistory_FI_1` (`clientQuoteId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Historial de Cotizacion a Cliente' AUTO_INCREMENT=36 ;

--
-- Dumping data for table `import_clientQuoteHistory`
--

INSERT INTO `import_clientQuoteHistory` (`id`, `clientQuoteId`, `status`, `createdAt`) VALUES
(1, 12, 2, '2009-03-06 11:03:48'),
(2, 13, 1, '2009-03-06 19:28:35'),
(3, 14, 1, '2009-03-09 14:48:55'),
(4, 14, 2, '2009-03-09 14:49:25'),
(5, 15, 1, '2009-03-17 17:25:43'),
(6, 16, 1, '2009-03-17 17:26:26'),
(7, 17, 1, '2009-03-17 17:28:01'),
(8, 18, 1, '2009-03-17 20:25:50'),
(9, 15, 2, '2009-03-17 20:36:38'),
(10, 19, 1, '2009-03-17 20:37:25'),
(11, 13, 2, '2009-03-17 20:42:06'),
(12, 12, 3, '2009-03-17 20:46:50'),
(13, 20, 1, '2009-03-17 21:11:31'),
(14, 17, 2, '2009-03-17 21:14:35'),
(15, 17, 3, '2009-03-17 21:30:06'),
(16, 5, 3, '2009-03-17 22:28:07'),
(17, 16, 2, '2009-03-17 22:37:15'),
(18, 5, 4, '2009-03-17 23:41:27'),
(19, 5, 5, '2009-03-17 23:42:04'),
(20, 21, 1, '2009-03-17 23:49:09'),
(21, 21, 2, '2009-03-17 23:51:23'),
(22, 22, 1, '2009-03-18 00:14:52'),
(23, 22, 2, '2009-03-18 00:15:38'),
(24, 5, 6, '2009-03-27 16:56:16'),
(25, 9, 3, '2009-03-27 17:06:34'),
(26, 23, 1, '2009-03-27 17:11:34'),
(27, 23, 2, '2009-03-27 17:11:56'),
(28, 23, 3, '2009-03-27 17:13:33'),
(29, 24, 2, '2009-04-17 21:58:54'),
(30, 25, 2, '2009-04-17 22:00:45'),
(31, 25, 3, '2009-04-17 22:02:22'),
(32, 26, 2, '2009-05-01 14:27:34'),
(33, 27, 2, '2009-05-01 14:40:55'),
(34, 28, 2, '2009-05-01 14:51:32'),
(35, 29, 2, '2009-05-08 14:04:35');

-- --------------------------------------------------------

--
-- Table structure for table `import_clientQuoteItem`
--

DROP TABLE IF EXISTS `import_clientQuoteItem`;
CREATE TABLE IF NOT EXISTS `import_clientQuoteItem` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Id elemento de cotizacion de Cliente',
  `clientQuoteId` int(11) NOT NULL COMMENT 'Id de cotizacion de cliente',
  `productId` int(11) NOT NULL COMMENT 'Id producto',
  `price` float default NULL COMMENT 'precio de producto',
  `quantity` int(11) default NULL COMMENT 'cantidad de producto',
  PRIMARY KEY  (`id`),
  KEY `import_clientQuoteItem_FI_1` (`clientQuoteId`),
  KEY `import_clientQuoteItem_FI_2` (`productId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Elemento de Cotizacion Cliente' AUTO_INCREMENT=55 ;

--
-- Dumping data for table `import_clientQuoteItem`
--

INSERT INTO `import_clientQuoteItem` (`id`, `clientQuoteId`, `productId`, `price`, `quantity`) VALUES
(1, 2, 1, NULL, 500),
(2, 2, 2, NULL, 800),
(3, 3, 2, NULL, 500),
(4, 3, 2, NULL, 5000),
(5, 3, 1, NULL, 1000),
(6, 3, 1, NULL, 500),
(7, 3, 1, NULL, 1000),
(8, 4, 2, NULL, 1000),
(9, 4, 1, NULL, 2000),
(10, 5, 1, 6, 600),
(11, 5, 2, 50, 800),
(12, 6, 1, NULL, 2500),
(13, 6, 2, NULL, 4500),
(14, 7, 1, NULL, 4),
(15, 8, 2, NULL, 700),
(16, 9, 2, NULL, 230),
(17, 11, 3, NULL, 5000),
(18, 12, 1, NULL, 800),
(19, 12, 2, NULL, 1500),
(20, 12, 3, NULL, 2000),
(21, 14, 1, NULL, 2500),
(22, 14, 2, NULL, 4000),
(23, 14, 3, NULL, 6000),
(24, 15, 3, NULL, 3000),
(25, 15, 1, NULL, 500),
(26, 15, 3, NULL, 10),
(27, 13, 1, NULL, 0),
(28, 13, 2, NULL, 0),
(29, 13, 3, NULL, 3),
(30, 17, 1, NULL, 100),
(31, 17, 2, NULL, 200),
(32, 17, 3, NULL, 300),
(33, 16, 1, NULL, 273),
(34, 21, 3, NULL, 1000),
(35, 22, 3, NULL, 455),
(36, 18, 1, NULL, 1),
(37, 18, 2, NULL, 1),
(38, 18, 1, NULL, 1),
(39, 18, 1, NULL, 1),
(40, 18, 2, NULL, 1),
(41, 18, 3, NULL, 1),
(42, 18, 1, NULL, 1),
(43, 18, 2, NULL, 1),
(44, 18, 3, NULL, 1),
(45, 18, 1, NULL, 1),
(46, 23, 1, NULL, 1),
(47, 20, 1, NULL, 1),
(48, 25, 3, NULL, 1),
(49, 27, 3, NULL, 1),
(50, 28, 1, NULL, 1),
(51, 28, 2, NULL, 1),
(52, 28, 3, NULL, 1),
(53, 29, 1, NULL, 1),
(54, 29, 2, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `import_incoterm`
--

DROP TABLE IF EXISTS `import_incoterm`;
CREATE TABLE IF NOT EXISTS `import_incoterm` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Incoterm Id',
  `name` varchar(255) collate latin1_general_cs default NULL COMMENT 'Nombre del Incoterm',
  `description` varchar(255) collate latin1_general_cs default NULL COMMENT 'Descripcion del Incoterm',
  `active` tinyint(4) NOT NULL COMMENT 'Is incoterm active?',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Incoterm' AUTO_INCREMENT=3 ;

--
-- Dumping data for table `import_incoterm`
--

INSERT INTO `import_incoterm` (`id`, `name`, `description`, `active`) VALUES
(1, 'FOB', 'Free On Board', 1),
(2, 'CIF', 'Cost Insurance & Freight', 1);

-- --------------------------------------------------------

--
-- Table structure for table `import_port`
--

DROP TABLE IF EXISTS `import_port`;
CREATE TABLE IF NOT EXISTS `import_port` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Port Id',
  `code` varchar(255) collate latin1_general_cs default NULL COMMENT 'Codigo del puerto',
  `name` varchar(255) collate latin1_general_cs default NULL COMMENT 'Nombre del puerto',
  `active` tinyint(4) NOT NULL COMMENT 'Is port active?',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Puerto' AUTO_INCREMENT=5 ;

--
-- Dumping data for table `import_port`
--

INSERT INTO `import_port` (`id`, `code`, `name`, `active`) VALUES
(1, 'LAG', 'La Guaira, VE', 1),
(2, 'PBL', 'Puerto Cabello, VE', 1),
(3, 'PTY', 'PanamÃ¡, PA', 1),
(4, 'SHA', 'Shanghai, CN', 1);

-- --------------------------------------------------------

--
-- Table structure for table `import_product`
--

DROP TABLE IF EXISTS `import_product`;
CREATE TABLE IF NOT EXISTS `import_product` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Product Id',
  `code` varchar(255) default NULL COMMENT 'Codigo del producto',
  `name` varchar(255) default NULL COMMENT 'Nombre del producto en ingles',
  `nameSpanish` varchar(255) default NULL COMMENT 'Nombre del producto en espaniol',
  `description` text COMMENT 'Descripcion del producto en ingles',
  `descriptionSpanish` text COMMENT 'Descripcion del producto en espaniol',
  `nameChinese` varchar(255) default NULL COMMENT 'Nombre del producto en chino',
  `descriptionChinese` text COMMENT 'Descripcion del producto en chino',
  `status` int(11) NOT NULL COMMENT 'product status',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='Productos' AUTO_INCREMENT=4 ;

--
-- Dumping data for table `import_product`
--

INSERT INTO `import_product` (`id`, `code`, `name`, `nameSpanish`, `description`, `descriptionSpanish`, `nameChinese`, `descriptionChinese`, `status`) VALUES
(1, '01100021', 'ABC Fire Extinguisher', 'Extintor de Incendios tipo ABC', 'Specifications on product detail pages provided by manufacturers relating to the speed (including printer speed), performance, capabilities, and functionality of their products are typically provided for comparative purposes. The actual speed (including printer speed), performance, capabilities and functionality of your product will vary with use.', 'Extintor de Incendios tipo ABC, Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tatio', 'ç¾Žå›½å¹¿æ’­å…¬å¸ç­ç«å™¨', 'è§„æ ¼äº§å“è¯¦ç»†é¡µæœ‰å…³åˆ¶é€ å•†æä¾›çš„é€Ÿåº¦ï¼ˆåŒ…æ‹¬æ‰“å°æœºçš„é€Ÿåº¦ï¼‰ ï¼Œæ€§èƒ½ï¼ŒåŠŸèƒ½å’ŒåŠŸèƒ½çš„äº§å“é€šå¸¸æä¾›ï¼Œä»¥ä¾¿äºŽæ¯”è¾ƒã€‚å®žé™…é€Ÿåº¦ï¼ˆåŒ…æ‹¬æ‰“å°æœºçš„é€Ÿåº¦ï¼‰ ï¼Œæ€§èƒ½ï¼ŒåŠŸèƒ½å’ŒåŠŸèƒ½çš„äº§å“å°†éšä½¿ç”¨ã€‚', 1),
(2, '0120001', 'Type ABC Fire Extinguisher 5 - Rechargeable ', 'Extintor de Incendios tipo ABC Recargable.', ' This stored pressure multi-purpose Type ABC fire extinguisher is extremely versatile. It will tackle the majority of fire risks found in most commercial, industrial and domestic environments. This 5 lb. Type ABC fire extinguisher is fully charged and tagged. It includes a wall hook.\r\n\r\nPlease Note: Due to the hazardous nature of this product, it must ship via common carrier. It makes the most sense to order several of this product at once or to combine it with other products. That way, the shipping cost per case is reduced. ', 'Extintor TIPO ABC, recargable Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tatio', 'ç¾Žå›½å¹¿æ’­å…¬å¸åž‹ç­ç«å™¨5 -å……ç”µ', 'æ­¤å­˜å‚¨åŽ‹åŠ›å¤šç”¨é€”åž‹ç¾Žå›½å¹¿æ’­å…¬å¸ç­ç«å™¨éžå¸¸å¤šæ‰å¤šè‰ºã€‚è¿™å°†è§£å†³å¤§å¤šæ•°ç«ç¾é£Žé™©ï¼Œå¤šæ•°å•†ä¸šï¼Œå·¥ä¸šå’Œå›½å†…çŽ¯å¢ƒã€‚è¿™äº”è‹±é•‘ç±»åž‹ç¾Žå›½å¹¿æ’­å…¬å¸ç­ç«å™¨å®Œå…¨å……ç”µå’Œæ ‡è®°ã€‚å®ƒåŒ…æ‹¬ä¸€ä¸ªå£é’©ã€‚\r\n\r\nè¯·æ³¨æ„ï¼šç”±äºŽå±é™©æ€§çš„äº§å“ï¼Œå®ƒå¿…é¡»é€šè¿‡å…±åŒçš„èˆ¹æ‰¿è¿äººã€‚å®ƒä½¿æœ€åˆç†çš„ç§©åºå‡ ä¸ªæ­¤äº§å“ä¸€æ¬¡æˆ–ç»“åˆå…¶å®ƒäº§å“ã€‚è¿™æ ·ï¼Œæ¯ä¸ªæ¡ˆä»¶èˆªè¿æˆæœ¬é™ä½Žã€‚', 1),
(3, '3002001', 'Coaxial Cable White RG59 Inner 64 x 0.12', 'Cable coaxial blango RG59 64 x 0.12', 'Conductor Stranding No./mm/1/0.643,MTRL,CCS	\r\nInsulation: 3.7 FOAM PE	\r\nAl Foil: Al May	\r\nBraid Shield MTRL: Al May	\r\nNOM OD mm:6.0	\r\nThe cable with Impeddance and Attenuation as confirmed.	\r\nThe main wire is steel covered by copper.	\r\nThe knitted wire is copper.	\r\nThe presentation is in plastic spool, coaxial cable rolled by PVC film, 	\r\n2 spool pcs in Master Box	\r\n-The measurement of spool 25cm high and 25cm diameter.	\r\nTo write in the PVC cable: COAXIAL CABLE RG59 75 OHM.	\r\nPresentation 1000 Foot by Plastic Spool                                             	\r\n', 'Encallamiento No./mm/1/0.643 conductor, MTRL, CCS\r\nAislamiento: 3,7 ESPUMA PE\r\nAl Foil: Al mayo\r\nBraid MTRL Shield: Al mayo\r\nNOM OD mm: 6,0\r\nEl cable de atenuaciÃ³n con Impeddance y como lo confirma.\r\nEl principal es el alambre de acero cubierta de cobre.\r\nEl punto es alambre de cobre.\r\nLa presentaciÃ³n es en bobina de plÃ¡stico, cable coaxial de PVC laminado de pelÃ­cula,\r\n2 pzs en la cola Master Caja\r\n-La mediciÃ³n de la bobina de 25cm de alto y 25cm de diÃ¡metro.\r\nPara escribir en el cable de PVC: CABLE COAXIAL RG59 75 OHM.\r\n1000 PresentaciÃ³n del pie por la cola de plÃ¡stico', 'ç™½å®«RG59åŒè½´ç”µç¼†å†…è’™å¤64 Ã— 0.12', 'å¯¼ä½“ç»žNo./mm/1/0.643 ï¼Œ MTRL ï¼Œä¸­é€šæœ\r\nç»ç¼˜ï¼š 3.7å‘æ³¡èšä¹™çƒ¯\r\né“ç®”ï¼šé“5æœˆ\r\nç¼–ç»‡å±è”½MTRL ï¼šé“5æœˆ\r\nå¤©ç„¶æœ‰æœºç‰©çš„ODæ¯«ç±³ï¼š 6.0\r\nè¯¥ç”µç¼†çš„è¡°å‡ä¸ŽImpeddanceå’Œè¯å®žã€‚\r\nä¸»è¦æ˜¯é’¢çº¿æ‰€æ¶µç›–é“œã€‚\r\né’ˆç»‡çº¿æ˜¯é“œã€‚\r\nè¿™æ¬¡æŠ¥å‘Šä¼šæ˜¯åœ¨å¡‘æ–™é˜€èŠ¯ï¼ŒåŒè½´ç”µç¼†æŽ¨å‡ºçš„PVCè–„è†œï¼Œ\r\n2é˜€èŠ¯ç”µè„‘ç¡•å£«ç›’\r\n-é˜€èŠ¯æµ‹é‡å’Œ25åŽ˜ç±³é«˜25åŽ˜ç±³ç›´å¾„ã€‚\r\nå†™åœ¨PVCç”µç¼†ï¼šåŒè½´ç”µç¼†RG59 75æ¬§å§†ã€‚\r\nä»‹ç»1000å¹´è¶³å¡‘æ–™é˜€èŠ¯', 1);

-- --------------------------------------------------------

--
-- Table structure for table `import_productSupplier`
--

DROP TABLE IF EXISTS `import_productSupplier`;
CREATE TABLE IF NOT EXISTS `import_productSupplier` (
  `productId` int(11) NOT NULL COMMENT 'Product Id',
  `supplierId` varchar(255) collate latin1_general_cs default NULL COMMENT 'Nombre del producto',
  `code` varchar(255) collate latin1_general_cs default NULL COMMENT 'Codigo del producto',
  PRIMARY KEY  (`productId`),
  KEY `import_productSupplier_FI_2` (`supplierId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Relacion Productos Proveedores';

--
-- Dumping data for table `import_productSupplier`
--

INSERT INTO `import_productSupplier` (`productId`, `supplierId`, `code`) VALUES
(1, '1', '466142'),
(2, '1', '4725ABC'),
(3, '2', 'CHJ-606');

-- --------------------------------------------------------

--
-- Table structure for table `import_purchaseOrderItem`
--

DROP TABLE IF EXISTS `import_purchaseOrderItem`;
CREATE TABLE IF NOT EXISTS `import_purchaseOrderItem` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Id elemento de Orden de Pedido a Cliente',
  `productId` int(11) NOT NULL COMMENT 'Id producto',
  `supplierPurchaseOrderId` int(11) NOT NULL COMMENT 'Id producto',
  `price` float default NULL COMMENT 'Id producto',
  `quantity` int(11) default NULL COMMENT 'Id producto',
  PRIMARY KEY  (`id`),
  KEY `import_purchaseOrderItem_FI_1` (`productId`),
  KEY `import_purchaseOrderItem_FI_2` (`supplierPurchaseOrderId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Elemento de Orden de Pedido a Cliente' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `import_purchaseOrderItem`
--


-- --------------------------------------------------------

--
-- Table structure for table `import_supplier`
--

DROP TABLE IF EXISTS `import_supplier`;
CREATE TABLE IF NOT EXISTS `import_supplier` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate latin1_general_cs NOT NULL COMMENT 'Nombre',
  `email` varchar(255) collate latin1_general_cs default NULL COMMENT 'email',
  `active` tinyint(4) NOT NULL COMMENT 'Is supplier active?',
  `defaultIncotermId` int(11) default NULL COMMENT 'id de incoterm por default del proveedor',
  `defaultPortId` int(11) default NULL COMMENT 'id de puerto por default del proveedor',
  PRIMARY KEY  (`id`),
  KEY `import_supplier_FI_1` (`defaultIncotermId`),
  KEY `import_supplier_FI_2` (`defaultPortId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Proveedores' AUTO_INCREMENT=3 ;

--
-- Dumping data for table `import_supplier`
--

INSERT INTO `import_supplier` (`id`, `name`, `email`, `active`, `defaultIncotermId`, `defaultPortId`) VALUES
(1, 'Shanghai International LTD', 'jcalfonzo@gmail.com', 1, NULL, NULL),
(2, 'Wan Chai Commertial', 'gflamerich@gmail.com', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `import_supplierPurchaseOrder`
--

DROP TABLE IF EXISTS `import_supplierPurchaseOrder`;
CREATE TABLE IF NOT EXISTS `import_supplierPurchaseOrder` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Id de Orden de Pedido de Cliente',
  `createdAt` datetime NOT NULL COMMENT 'Creation date for',
  `supplierId` int(11) NOT NULL COMMENT 'Supplier',
  `status` int(11) NOT NULL COMMENT 'Status de Cotizacion',
  `timestampStatus` datetime default NULL COMMENT 'Fecha del ultimo cambio de status',
  `supplierQuoteId` int(11) NOT NULL COMMENT 'id de cotizacion de proveedor relacionada',
  `clientQuoteId` int(11) NOT NULL COMMENT 'id de cotizacion a cliente relacionada',
  `affiliateId` int(11) NOT NULL COMMENT 'Afiliado',
  `affiliateUserId` int(11) default NULL COMMENT 'usuario del afiliado si creo la cotizacion',
  `userId` int(11) default NULL COMMENT 'Usuario de anmaga si creo la cotizacion',
  PRIMARY KEY  (`id`),
  KEY `import_supplierPurchaseOrder_FI_1` (`supplierQuoteId`),
  KEY `import_supplierPurchaseOrder_FI_2` (`clientQuoteId`),
  KEY `import_supplierPurchaseOrder_FI_3` (`supplierId`),
  KEY `import_supplierPurchaseOrder_FI_4` (`userId`),
  KEY `import_supplierPurchaseOrder_FI_5` (`affiliateId`),
  KEY `import_supplierPurchaseOrder_FI_6` (`affiliateUserId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Orden de Pedido a Proveedor' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `import_supplierPurchaseOrder`
--

INSERT INTO `import_supplierPurchaseOrder` (`id`, `createdAt`, `supplierId`, `status`, `timestampStatus`, `supplierQuoteId`, `clientQuoteId`, `affiliateId`, `affiliateUserId`, `userId`) VALUES
(1, '2009-03-27 16:56:15', 1, 1, NULL, 1, 1, 1, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `import_supplierPurchaseOrderBankTransfer`
--

DROP TABLE IF EXISTS `import_supplierPurchaseOrderBankTransfer`;
CREATE TABLE IF NOT EXISTS `import_supplierPurchaseOrderBankTransfer` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Id',
  `supplierPurchaseOrderId` int(11) NOT NULL COMMENT 'Id de orden de pedido a proveedor',
  `bankTransferNumber` varchar(255) collate latin1_general_cs NOT NULL COMMENT 'numero de transferencia bancaria.',
  `amount` float NOT NULL COMMENT 'monto de la transferencia bancaria.',
  `accountNumber` varchar(255) collate latin1_general_cs NOT NULL COMMENT 'Numero de cuenta bancaria destino',
  `bankAccountId` int(11) NOT NULL COMMENT 'Cuenta bancaria origen',
  `createdAt` datetime NOT NULL COMMENT 'Creation date for',
  PRIMARY KEY  (`id`),
  KEY `import_supplierPurchaseOrderBankTransfer_FI_1` (`supplierPurchaseOrderId`),
  KEY `import_supplierPurchaseOrderBankTransfer_FI_2` (`bankAccountId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Transferencias bancarias realizadas a esa orden de pedido a ' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `import_supplierPurchaseOrderBankTransfer`
--


-- --------------------------------------------------------

--
-- Table structure for table `import_supplierPurchaseOrderHistory`
--

DROP TABLE IF EXISTS `import_supplierPurchaseOrderHistory`;
CREATE TABLE IF NOT EXISTS `import_supplierPurchaseOrderHistory` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Id',
  `supplierPurchaseOrderId` int(11) NOT NULL COMMENT 'Id de orden de pedido a proveedor',
  `status` int(11) NOT NULL COMMENT 'Codigo del estado guardado.',
  `comments` varchar(255) collate latin1_general_cs default NULL COMMENT 'Comentarios.',
  `createdAt` datetime NOT NULL COMMENT 'Creation date for',
  PRIMARY KEY  (`id`),
  KEY `import_supplierPurchaseOrderHistory_FI_1` (`supplierPurchaseOrderId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Historial de Estados por los que fue pasando la Orden de Ped' AUTO_INCREMENT=2 ;

--
-- Dumping data for table `import_supplierPurchaseOrderHistory`
--

INSERT INTO `import_supplierPurchaseOrderHistory` (`id`, `supplierPurchaseOrderId`, `status`, `comments`, `createdAt`) VALUES
(1, 1, 1, NULL, '2009-03-27 16:56:16');

-- --------------------------------------------------------

--
-- Table structure for table `import_supplierPurchaseOrderItem`
--

DROP TABLE IF EXISTS `import_supplierPurchaseOrderItem`;
CREATE TABLE IF NOT EXISTS `import_supplierPurchaseOrderItem` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Id elemento de Orden de Pedido a Cliente',
  `productId` int(11) NOT NULL COMMENT 'Id producto',
  `supplierPurchaseOrderId` int(11) NOT NULL COMMENT 'Id producto',
  `quantity` int(11) default NULL COMMENT 'Id producto',
  `portId` int(11) NOT NULL COMMENT 'id de puerto',
  `incotermId` int(11) NOT NULL COMMENT 'id de incoterm',
  `price` float default NULL COMMENT 'precio de producto',
  `delivery` int(11) default NULL COMMENT 'Tiempo en dias para la entrega del producto.',
  `package` int(11) default NULL COMMENT 'A seleccionar entre Unidades o Bultos',
  `unitLength` float default NULL COMMENT 'Largo del empaque de la unidad ',
  `unitWidth` float default NULL COMMENT 'Ancho del empaque de la unidad ',
  `unitHeight` float default NULL COMMENT 'Alto del empaque de la unidad ',
  `unitGrossWeigth` float default NULL COMMENT 'Peso del empaque de la unidad ',
  `unitsPerCarton` int(11) default NULL COMMENT 'Unidades por bulto',
  `cartons` int(11) default NULL COMMENT 'Cantidad de bultos',
  `cartonLength` float default NULL COMMENT 'Largo del bulto',
  `cartonWidth` float default NULL COMMENT 'Ancho del bulto',
  `cartonHeight` float default NULL COMMENT 'Alto del bulto',
  `cartonGrossWeigth` float default NULL COMMENT 'Peso del bulto',
  PRIMARY KEY  (`id`),
  KEY `import_supplierPurchaseOrderItem_FI_1` (`productId`),
  KEY `import_supplierPurchaseOrderItem_FI_2` (`supplierPurchaseOrderId`),
  KEY `import_supplierPurchaseOrderItem_FI_3` (`incotermId`),
  KEY `import_supplierPurchaseOrderItem_FI_4` (`portId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Elemento de Orden de Pedido a Proveedor' AUTO_INCREMENT=3 ;

--
-- Dumping data for table `import_supplierPurchaseOrderItem`
--

INSERT INTO `import_supplierPurchaseOrderItem` (`id`, `productId`, `supplierPurchaseOrderId`, `quantity`, `portId`, `incotermId`, `price`, `delivery`, `package`, `unitLength`, `unitWidth`, `unitHeight`, `unitGrossWeigth`, `unitsPerCarton`, `cartons`, `cartonLength`, `cartonWidth`, `cartonHeight`, `cartonGrossWeigth`) VALUES
(1, 1, 1, 600, 4, 1, 4, 30, 2, 18, 35, 21, 0.25, 12, NULL, 90, 80, 120, 4),
(2, 2, 1, 800, 4, 1, 25, 60, 1, 10, 10, 20, 8, 1, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `import_supplierPurchaseOrderStatus`
--

DROP TABLE IF EXISTS `import_supplierPurchaseOrderStatus`;
CREATE TABLE IF NOT EXISTS `import_supplierPurchaseOrderStatus` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Id',
  `supplierPurchaseOrderId` int(11) NOT NULL COMMENT 'Id de orden de pedido a proveedor',
  `statusCode` int(11) NOT NULL COMMENT 'Codigo del estado guardado.',
  `createdAt` datetime NOT NULL COMMENT 'Creation date for',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Historial de Estados por los que fue pasando la Orden de Ped' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `import_supplierPurchaseOrderStatus`
--


-- --------------------------------------------------------

--
-- Table structure for table `import_supplierQuote`
--

DROP TABLE IF EXISTS `import_supplierQuote`;
CREATE TABLE IF NOT EXISTS `import_supplierQuote` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Id de cotizacion de proveedor',
  `createdAt` datetime NOT NULL COMMENT 'Creation date for',
  `supplierId` int(11) NOT NULL COMMENT 'Supplier',
  `status` int(11) NOT NULL COMMENT 'Status de Cotizacion',
  `timestampStatus` datetime default NULL COMMENT 'Fecha del ultimo cambio de status',
  `clientQuoteId` int(11) default NULL COMMENT 'id de cotizacion relacionada',
  `supplierAccessToken` varchar(255) collate latin1_general_cs NOT NULL COMMENT 'token de validacion del acceso al proveedor a la orden',
  PRIMARY KEY  (`id`),
  KEY `import_supplierQuote_FI_1` (`clientQuoteId`),
  KEY `import_supplierQuote_FI_2` (`supplierId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Cotizacion de Proveedor' AUTO_INCREMENT=14 ;

--
-- Dumping data for table `import_supplierQuote`
--

INSERT INTO `import_supplierQuote` (`id`, `createdAt`, `supplierId`, `status`, `timestampStatus`, `clientQuoteId`, `supplierAccessToken`) VALUES
(1, '2009-02-14 12:02:09', 1, 1, '2009-02-14 12:02:09', 4, 'bba9047926f297e504e5c666bc2cd978163c41a8'),
(2, '2009-02-20 11:55:29', 1, 1, '2009-02-20 11:55:29', 5, '036dcec0b2787dbe0d2c2413940319bdea3cff55'),
(3, '2009-02-24 10:57:57', 1, 4, '2009-02-24 10:57:57', 5, '82dd89c67a735a5d89650b96282cc75a06f59211'),
(4, '2009-03-06 11:04:33', 1, 1, '2009-03-06 11:04:33', 12, '506b2f1155fd2076c72a7304338733f383cf2ab2'),
(5, '2009-03-17 21:17:21', 1, 4, '2009-03-17 21:17:21', 17, '8876abf66dc18587f22aa11d5f68c8a4c677e4a7'),
(6, '2009-03-17 23:25:35', 1, 3, '2009-03-17 23:25:35', 3, 'ee146401302ab2dd191b0f30e2de9855e08374ac'),
(7, '2009-03-17 23:53:53', 2, 2, '2009-03-17 23:53:53', 21, '4797822b36c191ce6b3b41b97f03dcb49f6805cf'),
(8, '2009-03-27 17:00:49', 1, 2, '2009-03-27 17:00:49', 4, '9f4cb1610e25a8d61823fd9c11c6d9b23d0de4e1'),
(9, '2009-03-27 17:05:32', 1, 4, '2009-03-27 17:05:32', 9, '487f8607411132593ee6a8e47b761d1c151d5fa3'),
(10, '2009-03-27 17:12:53', 1, 5, '2009-03-27 17:12:53', 23, 'c99d0f2a12044b84bcabf36454ac9715dcf67b07'),
(11, '2009-04-17 22:01:16', 2, 4, '2009-04-17 22:01:16', 25, 'e5ea3dc0113dd894710a5b63db560133a4170198'),
(12, '2009-05-01 14:57:12', 1, 2, '2009-05-01 14:57:12', 28, '240dac810b0eab29ef9eb7e6943d9b6aae710a82'),
(13, '2009-05-08 15:10:15', 1, 3, '2009-05-08 15:10:15', 29, 'a51d6222d7a1836d721ad06bd2bd987e8828971c');

-- --------------------------------------------------------

--
-- Table structure for table `import_supplierQuoteHistory`
--

DROP TABLE IF EXISTS `import_supplierQuoteHistory`;
CREATE TABLE IF NOT EXISTS `import_supplierQuoteHistory` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Id',
  `supplierQuoteId` int(11) NOT NULL COMMENT 'Id de la cotizacion de proveedor',
  `status` int(11) NOT NULL COMMENT 'Status de Cotizacion',
  `createdAt` datetime default NULL COMMENT 'Fecha del cambio de status',
  PRIMARY KEY  (`id`),
  KEY `import_supplierQuoteHistory_FI_1` (`supplierQuoteId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Historial de Cotizacion a Proveedor' AUTO_INCREMENT=32 ;

--
-- Dumping data for table `import_supplierQuoteHistory`
--

INSERT INTO `import_supplierQuoteHistory` (`id`, `supplierQuoteId`, `status`, `createdAt`) VALUES
(1, 4, 1, '2009-03-06 11:04:33'),
(2, 4, 2, '2009-03-06 11:04:41'),
(3, 4, 4, '2009-03-17 20:46:50'),
(4, 5, 1, '2009-03-17 21:17:21'),
(5, 5, 2, '2009-03-17 21:17:23'),
(6, 5, 3, '2009-03-17 21:25:04'),
(7, 5, 4, '2009-03-17 21:30:05'),
(8, 3, 4, '2009-03-17 22:28:07'),
(9, 6, 1, '2009-03-17 23:25:35'),
(10, 6, 2, '2009-03-17 23:25:37'),
(11, 7, 1, '2009-03-17 23:53:53'),
(12, 7, 2, '2009-03-17 23:53:55'),
(13, 8, 1, '2009-03-27 17:00:49'),
(14, 8, 2, '2009-03-27 17:00:51'),
(15, 6, 3, '2009-03-27 17:01:34'),
(16, 9, 1, '2009-03-27 17:05:32'),
(17, 9, 2, '2009-03-27 17:05:34'),
(18, 9, 3, '2009-03-27 17:06:25'),
(19, 9, 4, '2009-03-27 17:06:34'),
(20, 10, 1, '2009-03-27 17:12:53'),
(21, 10, 2, '2009-03-27 17:12:55'),
(22, 10, 3, '2009-03-27 17:13:25'),
(23, 10, 4, '2009-03-27 17:13:33'),
(24, 10, 5, '2009-04-17 18:02:08'),
(25, 11, 1, '2009-04-17 22:01:16'),
(26, 11, 2, '2009-04-17 22:01:16'),
(27, 11, 3, '2009-04-17 22:02:13'),
(28, 11, 4, '2009-04-17 22:02:22'),
(29, 12, 1, '2009-05-01 14:57:12'),
(30, 13, 1, '2009-05-08 15:10:15'),
(31, 13, 3, '2009-05-08 17:06:33');

-- --------------------------------------------------------

--
-- Table structure for table `import_supplierQuoteItem`
--

DROP TABLE IF EXISTS `import_supplierQuoteItem`;
CREATE TABLE IF NOT EXISTS `import_supplierQuoteItem` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Id elemento de cotizacion de proveedor',
  `supplierQuoteId` int(11) NOT NULL COMMENT 'Id de cotizacion de proveedor',
  `productId` int(11) NOT NULL COMMENT 'Id producto',
  `clientQuoteItemId` int(11) NOT NULL COMMENT 'Id de cotizacion de proveedor',
  `status` int(11) NOT NULL COMMENT 'Status de Cotizacion',
  `quantity` int(11) NOT NULL COMMENT 'cantidad producto',
  `portId` int(11) NOT NULL COMMENT 'id de puerto',
  `incotermId` int(11) NOT NULL COMMENT 'id de incoterm',
  `price` float default NULL COMMENT 'precio de producto',
  `supplierComments` varchar(255) collate latin1_general_cs default NULL COMMENT 'Comentarios del proveedor ',
  `delivery` int(11) default NULL COMMENT 'Tiempo en dias para la entrega del producto.',
  `package` int(11) default NULL COMMENT 'A seleccionar entre Unidades o Bultos',
  `unitLength` float default NULL COMMENT 'Largo del empaque de la unidad ',
  `unitWidth` float default NULL COMMENT 'Ancho del empaque de la unidad ',
  `unitHeight` float default NULL COMMENT 'Alto del empaque de la unidad ',
  `unitGrossWeigth` float default NULL COMMENT 'Peso del empaque de la unidad ',
  `unitsPerCarton` int(11) default NULL COMMENT 'Unidades por bulto',
  `cartons` int(11) default NULL COMMENT 'Cantidad de bultos',
  `cartonLength` float default NULL COMMENT 'Largo del bulto',
  `cartonWidth` float default NULL COMMENT 'Ancho del bulto',
  `cartonHeight` float default NULL COMMENT 'Alto del bulto',
  `cartonGrossWeigth` float default NULL COMMENT 'Peso del bulto',
  `replacedProductId` int(11) default NULL COMMENT 'Id producto que fue reemplazado por el actual',
  PRIMARY KEY  (`id`),
  KEY `import_supplierQuoteItem_FI_1` (`supplierQuoteId`),
  KEY `import_supplierQuoteItem_FI_2` (`clientQuoteItemId`),
  KEY `import_supplierQuoteItem_FI_3` (`productId`),
  KEY `import_supplierQuoteItem_FI_4` (`incotermId`),
  KEY `import_supplierQuoteItem_FI_5` (`portId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Elemento de Cotizacion de Proveedor' AUTO_INCREMENT=23 ;

--
-- Dumping data for table `import_supplierQuoteItem`
--

INSERT INTO `import_supplierQuoteItem` (`id`, `supplierQuoteId`, `productId`, `clientQuoteItemId`, `status`, `quantity`, `portId`, `incotermId`, `price`, `supplierComments`, `delivery`, `package`, `unitLength`, `unitWidth`, `unitHeight`, `unitGrossWeigth`, `unitsPerCarton`, `cartons`, `cartonLength`, `cartonWidth`, `cartonHeight`, `cartonGrossWeigth`, `replacedProductId`) VALUES
(1, 3, 1, 10, 0, 600, 4, 1, 4, 'Prueba de cotizaciÃ³n al proveedor', 30, 2, 18, 35, 21, 0.25, 12, NULL, 90, 80, 120, 4, NULL),
(2, 3, 2, 11, 0, 800, 4, 1, 25, 'Esta es otra prueba de la dinÃ¡mica', 60, 1, 10, 10, 20, 8, 1, NULL, NULL, NULL, NULL, NULL, NULL),
(3, 4, 1, 18, 2, 800, 4, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(4, 4, 2, 19, 0, 1500, 4, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(5, 4, 3, 20, 2, 2000, 4, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(6, 5, 1, 30, 0, 100, 1, 1, 100, NULL, 6, 2, 10, 10, 10, 10, 50, NULL, 20, 20, 20, 100, NULL),
(7, 5, 2, 31, 0, 200, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8, 6, 2, 3, 0, 500, 1, 1, 12, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9, 6, 2, 4, 2, 5000, 1, 1, 15, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(10, 6, 1, 5, 0, 1000, 1, 1, 25, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(11, 6, 1, 6, 0, 500, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(12, 6, 1, 7, 0, 1000, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(13, 7, 3, 34, 0, 1000, 2, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(14, 8, 2, 8, 0, 1000, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(15, 8, 1, 9, 0, 2000, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(16, 9, 2, 16, 2, 230, 1, 1, 14, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(17, 10, 1, 46, 2, 1, 1, 1, 18, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(18, 11, 3, 48, 2, 1, 1, 1, 15, NULL, 45, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(19, 12, 1, 50, 1, 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(20, 12, 2, 51, 1, 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(21, 13, 1, 53, 2, 1, 3, 2, 16, NULL, 30, 2, 8, 10, 10, 6, 8, NULL, 16, 20, 20, 48, NULL),
(22, 13, 2, 54, 1, 1, 3, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `import_supplierQuoteItemComment`
--

DROP TABLE IF EXISTS `import_supplierQuoteItemComment`;
CREATE TABLE IF NOT EXISTS `import_supplierQuoteItemComment` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Id',
  `supplierQuoteItemId` int(11) NOT NULL COMMENT 'Id del item de la cotizacion de proveedor',
  `supplierId` int(11) NOT NULL COMMENT 'Supplier que comento',
  `userId` int(11) default NULL COMMENT 'Usuario de anmaga que comento',
  `price` float default NULL COMMENT 'precio de producto',
  `comments` varchar(255) collate latin1_general_cs default NULL COMMENT 'Comentarios',
  `delivery` int(11) default NULL COMMENT 'Tiempo en dias para la entrega del producto.',
  `createdAt` datetime default NULL COMMENT 'Fecha del cambio de status',
  PRIMARY KEY  (`id`),
  KEY `import_supplierQuoteItemComment_FI_1` (`userId`),
  KEY `import_supplierQuoteItemComment_FI_2` (`supplierId`),
  KEY `import_supplierQuoteItemComment_FI_3` (`supplierQuoteItemId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Feedback entre supplier y usuario admin de anmaga sobre un I' AUTO_INCREMENT=5 ;

--
-- Dumping data for table `import_supplierQuoteItemComment`
--

INSERT INTO `import_supplierQuoteItemComment` (`id`, `supplierQuoteItemId`, `supplierId`, `userId`, `price`, `comments`, `delivery`, `createdAt`) VALUES
(1, 17, 0, 1, 18, 'Me parece un poco alto el precio, hace 3 meses compramso el mismo producto por 16 dÃ³lares la unidad.', NULL, '2009-04-17 18:02:08'),
(2, 17, 1, NULL, 18, 'No podemos mejorar el precio, en vista del aumento del precio de la materia prima.\r\nPodemos esntregar en 20 dÃ­as, en lugar de 60.', NULL, '2009-04-17 18:05:14'),
(3, 18, 2, NULL, 15, '', 45, '2009-04-17 22:02:13'),
(4, 21, 1, NULL, 16, 'Datos de prueba', 30, '2009-05-08 17:06:33');

-- --------------------------------------------------------

--
-- Table structure for table `MLUSE_Language`
--

DROP TABLE IF EXISTS `MLUSE_Language`;
CREATE TABLE IF NOT EXISTS `MLUSE_Language` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL,
  `code` varchar(30) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `MLUSE_Language`
--


-- --------------------------------------------------------

--
-- Table structure for table `MLUSE_Text`
--

DROP TABLE IF EXISTS `MLUSE_Text`;
CREATE TABLE IF NOT EXISTS `MLUSE_Text` (
  `id` int(11) NOT NULL auto_increment,
  `languageId` int(11) NOT NULL,
  `text` text NOT NULL,
  PRIMARY KEY  (`id`,`languageId`),
  KEY `MLUSE_Text_ibfk_1` (`languageId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `MLUSE_Text`
--


-- --------------------------------------------------------

--
-- Table structure for table `modules_dependency`
--

DROP TABLE IF EXISTS `modules_dependency`;
CREATE TABLE IF NOT EXISTS `modules_dependency` (
  `moduleName` varchar(50) collate latin1_general_cs NOT NULL COMMENT 'Modulo',
  `dependence` varchar(50) collate latin1_general_cs NOT NULL COMMENT 'Modulos de los cuales depende',
  PRIMARY KEY  (`moduleName`,`dependence`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Dependencia de modulos ';

--
-- Dumping data for table `modules_dependency`
--


-- --------------------------------------------------------

--
-- Table structure for table `modules_label`
--

DROP TABLE IF EXISTS `modules_label`;
CREATE TABLE IF NOT EXISTS `modules_label` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Id module label',
  `name` varchar(255) collate latin1_general_cs NOT NULL COMMENT 'nombre del modulo',
  `label` varchar(255) collate latin1_general_cs default NULL COMMENT 'Etiqueta',
  `description` varchar(255) collate latin1_general_cs default NULL COMMENT 'Descripcion del modulo',
  `language` varchar(100) collate latin1_general_cs default NULL COMMENT 'idioma de la etiqueta',
  PRIMARY KEY  (`id`,`name`),
  KEY `modules_label_FI_1` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Etiquetas de modulos ' AUTO_INCREMENT=7 ;

--
-- Dumping data for table `modules_label`
--

INSERT INTO `modules_label` (`id`, `name`, `label`, `description`, `language`) VALUES
(6, 'backup', 'Backup', 'Manage system and information backups', 'eng'),
(5, 'backup', 'Respaldo', 'MÃ³dulo para creaciÃ³n y administraciÃ³n de copias de seguridad', 'esp');

-- --------------------------------------------------------

--
-- Table structure for table `modules_module`
--

DROP TABLE IF EXISTS `modules_module`;
CREATE TABLE IF NOT EXISTS `modules_module` (
  `name` varchar(255) collate latin1_general_cs NOT NULL COMMENT 'nombre del modulo',
  `active` tinyint(4) NOT NULL default '0' COMMENT 'Estado del modulo',
  `alwaysActive` tinyint(4) NOT NULL default '0' COMMENT 'Modulo siempre activo',
  `hasCategories` tinyint(4) NOT NULL default '0' COMMENT 'El Modulo tiene categorias relacionadas?',
  PRIMARY KEY  (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT=' Registro de modulos';

--
-- Dumping data for table `modules_module`
--

INSERT INTO `modules_module` (`name`, `active`, `alwaysActive`, `hasCategories`) VALUES
('common', 1, 0, 0),
('import', 1, 0, 0),
('users', 1, 0, 0),
('affiliates', 1, 0, 0),
('multilang', 1, 0, 0),
('backup', 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `multilang_language`
--

DROP TABLE IF EXISTS `multilang_language`;
CREATE TABLE IF NOT EXISTS `multilang_language` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(50) collate latin1_general_cs NOT NULL,
  `code` varchar(30) collate latin1_general_cs NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs AUTO_INCREMENT=4 ;

--
-- Dumping data for table `multilang_language`
--

INSERT INTO `multilang_language` (`id`, `name`, `code`) VALUES
(1, 'EspaÃ±ol', 'esp'),
(2, 'English', 'eng'),
(3, 'ä¸­æ–‡', 'cn');

-- --------------------------------------------------------

--
-- Table structure for table `multilang_text`
--

DROP TABLE IF EXISTS `multilang_text`;
CREATE TABLE IF NOT EXISTS `multilang_text` (
  `id` int(11) NOT NULL,
  `moduleName` varchar(255) collate latin1_general_cs NOT NULL,
  `languageId` int(11) NOT NULL,
  `text` text collate latin1_general_cs NOT NULL,
  PRIMARY KEY  (`id`,`moduleName`,`languageId`),
  KEY `multilang_text_FI_1` (`languageId`),
  KEY `multilang_text_FI_2` (`moduleName`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs;

--
-- Dumping data for table `multilang_text`
--

INSERT INTO `multilang_text` (`id`, `moduleName`, `languageId`, `text`) VALUES
(1, 'common', 1, 'Editar'),
(1, 'common', 2, 'Edit'),
(1, 'common', 3, 'ç¼–è¾‘'),
(2, 'common', 1, 'Eliminar'),
(2, 'common', 2, 'Delete'),
(2, 'common', 3, 'åˆ é™¤'),
(1, 'multilang', 1, 'Multi-idioma'),
(1, 'multilang', 2, 'Multilang'),
(1, 'multilang', 3, ''),
(2, 'multilang', 1, 'Administrar Idiomas'),
(2, 'multilang', 2, 'Manage Languages'),
(2, 'multilang', 3, ''),
(3, 'multilang', 1, 'Esta secciÃ³n le permitirÃ¡ administrar los idiomas disponibles en el sistema. Puede agregar un nuevo idioma, editar uno existente o eliminar un idioma determinado.'),
(3, 'multilang', 2, 'At the bottom is the list of the languages available at the system. You may add, edit or delete existing languages.'),
(3, 'multilang', 3, ''),
(4, 'multilang', 1, 'Idioma guardado correctamente'),
(4, 'multilang', 2, 'Laguange created sucessfully'),
(4, 'multilang', 3, ''),
(5, 'multilang', 1, 'Idioma eliminado correctamente'),
(5, 'multilang', 2, 'Language deleted sucessfully'),
(5, 'multilang', 3, ''),
(6, 'multilang', 1, 'Agregar idioma'),
(6, 'multilang', 2, 'Add language'),
(6, 'multilang', 3, ''),
(7, 'multilang', 1, 'Id'),
(7, 'multilang', 2, 'Id'),
(7, 'multilang', 3, ''),
(8, 'multilang', 1, 'Nombre'),
(8, 'multilang', 2, 'Name'),
(8, 'multilang', 3, ''),
(9, 'multilang', 1, 'CÃ³digo'),
(9, 'multilang', 2, 'Code'),
(9, 'multilang', 3, ''),
(10, 'multilang', 1, 'Â¿EstÃ¡ seguro que desea eliminar el idioma?'),
(10, 'multilang', 2, 'Do you really want to delete this language?'),
(10, 'multilang', 3, ''),
(11, 'multilang', 1, 'Editar Idioma'),
(11, 'multilang', 2, 'Edit language'),
(11, 'multilang', 3, ''),
(12, 'multilang', 1, 'A continuaciÃ³n se muestra el formulario de ediciÃ³n de idioma. Modifique los datos y haga click en &quot;Aceptar&quot; para guardar los cambios.'),
(12, 'multilang', 2, 'The following form allows you to edit a language. Edit the info and click on &quot;Accept&quot; to save changes'),
(12, 'multilang', 3, ''),
(13, 'multilang', 1, 'Crear Idioma'),
(13, 'multilang', 2, 'Create language'),
(13, 'multilang', 3, ''),
(14, 'multilang', 1, 'A continuaciÃ³n se muestra el formulario de creaciÃ³n de idioma. Ingrese los datos y haga click en &quot;Aceptar&quot; para crear el idioma.'),
(14, 'multilang', 2, 'The following form allosw you to create a new language. Input the language information and click &quot;Accept&quot; to create it.'),
(14, 'multilang', 3, ''),
(15, 'multilang', 1, 'Ha ocurrido un error al intentar guardar el idioma'),
(15, 'multilang', 2, 'An error ocurred when trying to save the language'),
(15, 'multilang', 3, ''),
(16, 'multilang', 1, 'Editar idioma'),
(16, 'multilang', 2, 'Edit language'),
(16, 'multilang', 3, ''),
(17, 'multilang', 1, 'Crear idioma'),
(17, 'multilang', 2, 'Create language'),
(17, 'multilang', 3, ''),
(3, 'common', 1, 'Aceptar'),
(3, 'common', 2, 'Accept'),
(3, 'common', 3, 'æŽ¥å—'),
(18, 'multilang', 1, 'Formulario de datos de idioma'),
(18, 'multilang', 2, 'Language information form'),
(18, 'multilang', 3, ''),
(19, 'multilang', 1, 'Ingrese los datos del idioma'),
(19, 'multilang', 2, 'Input the language information'),
(19, 'multilang', 3, ''),
(20, 'multilang', 1, 'Administrar Traducciones'),
(20, 'multilang', 2, 'Manage Translations'),
(20, 'multilang', 3, ''),
(4, 'common', 1, 'Buscar'),
(4, 'common', 2, 'Search'),
(4, 'common', 3, 'æœç´¢'),
(21, 'multilang', 1, 'Con esta aplicaciÃ³n puede administrar los textos que mostrarÃ¡ el sistema segÃºn el idioma del usuario. Seleccione un mÃ³dulo y agregue un nuevo texto o edite los valores actuales.'),
(21, 'multilang', 2, 'With this application, you can manage the text that uses the system according the user language. Select a module and add a new translation or edit the existing ones.'),
(21, 'multilang', 3, ''),
(22, 'multilang', 1, 'Formulario para selecciÃ³n de mÃ³dulo'),
(22, 'multilang', 2, 'Module selection form'),
(22, 'multilang', 3, ''),
(23, 'multilang', 1, 'SelecciÃ³n de MÃ³dulo'),
(23, 'multilang', 2, 'Module selection'),
(23, 'multilang', 3, ''),
(24, 'multilang', 1, 'MÃ³dulos disponibles'),
(24, 'multilang', 2, 'Available modules'),
(24, 'multilang', 3, ''),
(25, 'multilang', 1, 'Seleccione un mÃ³dulo'),
(25, 'multilang', 2, 'Select a module'),
(25, 'multilang', 3, ''),
(26, 'multilang', 1, 'Textos del mÃ³dulo'),
(26, 'multilang', 2, 'Module&#0039;s texts'),
(26, 'multilang', 3, ''),
(27, 'multilang', 1, 'Texto guardado correctamente'),
(27, 'multilang', 2, 'Succesfully saved text'),
(27, 'multilang', 3, ''),
(28, 'multilang', 1, 'Texto eliminado correctamente'),
(28, 'multilang', 2, 'Text successfully deleted'),
(28, 'multilang', 3, ''),
(29, 'multilang', 1, 'Agregar TraducciÃ³n'),
(29, 'multilang', 2, 'Add translations'),
(29, 'multilang', 3, ''),
(30, 'multilang', 1, 'No hay textos disponibles para el mÃ³dulo seleccionado'),
(30, 'multilang', 2, 'There are no translations for the selected module'),
(30, 'multilang', 3, ''),
(31, 'multilang', 1, 'Â¿EstÃ¡ seguro que desea eliminar estas traducciones?'),
(31, 'multilang', 2, 'Are you sure you want to delete this text?'),
(31, 'multilang', 3, ''),
(32, 'multilang', 1, 'Formulario de bÃºsqueda de traducciones'),
(32, 'multilang', 2, 'Translations search form'),
(32, 'multilang', 3, ''),
(33, 'multilang', 1, 'BÃºsqueda de textos'),
(33, 'multilang', 2, 'Text search'),
(33, 'multilang', 3, ''),
(34, 'multilang', 1, 'Seleccione un idioma'),
(34, 'multilang', 2, 'Select a language'),
(34, 'multilang', 3, ''),
(35, 'multilang', 1, 'Buscar texto'),
(35, 'multilang', 2, 'Text search'),
(35, 'multilang', 3, ''),
(5, 'common', 1, 'Inicio'),
(5, 'common', 2, 'First'),
(5, 'common', 3, 'ç¬¬'),
(6, 'common', 1, 'Anterior'),
(6, 'common', 2, 'Prev.'),
(6, 'common', 3, 'å‰'),
(7, 'common', 1, 'PÃ¡gina'),
(7, 'common', 2, 'Page'),
(7, 'common', 3, 'é¡µ'),
(8, 'common', 1, 'de'),
(8, 'common', 2, 'of'),
(8, 'common', 3, 'çš„'),
(9, 'common', 1, 'Siguiente'),
(9, 'common', 2, 'Next'),
(9, 'common', 3, 'ä¸‹'),
(10, 'common', 1, 'Ãšltima'),
(10, 'common', 2, 'Last'),
(10, 'common', 3, 'æœ€åŽ'),
(36, 'multilang', 1, 'Editar TraducciÃ³n'),
(36, 'multilang', 2, 'Edit Translation'),
(36, 'multilang', 3, ''),
(37, 'multilang', 1, 'A continuaciÃ³n se muestra el formulario de ediciÃ³n de traducciones. Modifique las traducciones y haga click en &quot;Aceptar&quot; para guardar los cambios.'),
(37, 'multilang', 2, 'The following form allows you to edit translations. Modify the texts and click on&quot;Accept&quot; to save changes.'),
(37, 'multilang', 3, ''),
(38, 'multilang', 1, 'Crear TraducciÃ³n'),
(38, 'multilang', 2, 'Create Translation'),
(38, 'multilang', 3, ''),
(39, 'multilang', 1, 'A continuaciÃ³n se muestra el formulario de creaciÃ³n de traducciones. Ingrese las traducciones y haga click en &quot;Aceptar&quot; para crear los textos.'),
(39, 'multilang', 2, 'The following form allows you to create translations. Input the translations and click &quot;Accept&quot; to create the texts.'),
(39, 'multilang', 3, ''),
(40, 'multilang', 1, 'Ha ocurrido un error al intentar guardar las traducciones'),
(40, 'multilang', 2, 'An error ocurred while trying to save the translations'),
(40, 'multilang', 3, ''),
(41, 'multilang', 1, 'Formulario de ediciÃ³n de datos de traducciÃ³n'),
(41, 'multilang', 2, 'Translations edit form'),
(41, 'multilang', 3, ''),
(42, 'multilang', 1, 'Ingrese las traducciones.'),
(42, 'multilang', 2, 'Input translations.'),
(42, 'multilang', 3, ''),
(43, 'multilang', 1, 'CÃ³digo de inserciÃ³n'),
(43, 'multilang', 2, 'Insertion code'),
(43, 'multilang', 3, ''),
(44, 'multilang', 1, 'Corresponde a mÃ³dulo'),
(44, 'multilang', 2, 'Belongs to module'),
(44, 'multilang', 3, ''),
(45, 'multilang', 1, 'Sin Modulo Asignado'),
(45, 'multilang', 2, 'Module not assigned'),
(45, 'multilang', 3, ''),
(46, 'multilang', 1, 'Resultados de la bÃºsqueda de textos en el mÃ³dulo:'),
(46, 'multilang', 2, 'Search results in module:'),
(46, 'multilang', 3, ''),
(47, 'multilang', 1, 'Idioma'),
(47, 'multilang', 2, 'Language'),
(47, 'multilang', 3, ''),
(48, 'multilang', 1, 'Texto buscado'),
(48, 'multilang', 2, 'Text searched'),
(48, 'multilang', 3, ''),
(49, 'multilang', 1, 'Ver todos'),
(49, 'multilang', 2, 'Display all'),
(49, 'multilang', 3, ''),
(50, 'multilang', 1, 'Su bÃºsqueda no obtuvo resultados'),
(50, 'multilang', 2, 'Theare no records that match your search'),
(50, 'multilang', 3, ''),
(1, 'import', 1, 'Exportaciones'),
(1, 'import', 2, 'Exports'),
(1, 'import', 3, 'å‡ºå£'),
(2, 'import', 1, 'Cotizaciones de Proveedor'),
(2, 'import', 2, 'Suppliers quotes'),
(2, 'import', 3, 'ä¾›åº”å•†æŠ¥ä»·'),
(3, 'import', 1, 'A continuaciÃ³n puede ver el listado de sus pedidos de cotizaciÃ³n a proveedores y sus correspondientes estados.'),
(3, 'import', 2, 'The following is a list of quotes requested to suppliers and their current status.'),
(3, 'import', 3, 'ä¸‹é¢åˆ—å‡ºçš„æŠ¥ä»·è¦æ±‚çš„ä¾›åº”å•†å’Œä»–ä»¬ç›®å‰çš„çŠ¶å†µ'),
(4, 'import', 1, 'Para ver las solicitudes de cotizaciÃ³n a un proveedor en particular, seleccione dicho proveedor de la lista'),
(4, 'import', 2, 'Select a supplier to filter the quotes request'),
(4, 'import', 3, 'é€‰æ‹©ä¸€ä¸ªä¾›åº”å•†çš„æŠ¥ä»·è¯·æ±‚è¿‡æ»¤'),
(5, 'import', 1, 'Filtrar por proveedores'),
(5, 'import', 2, 'Filter by supplier'),
(5, 'import', 3, ''),
(6, 'import', 1, 'Proveedor'),
(6, 'import', 2, 'Supplier'),
(6, 'import', 3, ''),
(7, 'import', 1, 'Seleccione un proveedor'),
(7, 'import', 2, 'Select a supplier'),
(7, 'import', 3, ''),
(8, 'import', 1, 'Aplicar Filtro'),
(8, 'import', 2, 'Filter requests'),
(8, 'import', 3, ''),
(9, 'import', 1, 'Id'),
(9, 'import', 2, 'Id'),
(9, 'import', 3, ''),
(10, 'import', 1, 'Fecha'),
(10, 'import', 2, 'Date'),
(10, 'import', 3, ''),
(11, 'import', 1, 'Estado'),
(11, 'import', 2, 'Status'),
(11, 'import', 3, ''),
(12, 'import', 1, 'Completar'),
(12, 'import', 2, 'Fill'),
(12, 'import', 3, ''),
(13, 'import', 1, 'Completar la solicitud con los datos suministrados por el proveedor'),
(13, 'import', 2, 'Fill the quote request form with the information provided by Supplier'),
(13, 'import', 3, 'å¡«å†™ç”³è¯·è¡¨çš„æŠ¥ä»·æä¾›çš„èµ„æ–™ä¾›åº”å•†'),
(14, 'import', 1, 'Editar'),
(14, 'import', 2, 'Edit'),
(14, 'import', 3, ''),
(15, 'import', 1, 'Editar Solicitud de CotizaciÃ³n'),
(15, 'import', 2, 'Edit quote request'),
(15, 'import', 3, 'ç¼–è¾‘æŠ¥ä»·è¯·æ±‚'),
(16, 'import', 1, 'Reenviar'),
(16, 'import', 2, 'Resend'),
(16, 'import', 3, ''),
(17, 'import', 1, 'Reenviar a Destinatario Original'),
(17, 'import', 2, 'Enviar a otros destinatarios'),
(17, 'import', 3, ''),
(18, 'import', 1, 'Ver Historial'),
(18, 'import', 2, 'Request Hitory'),
(18, 'import', 3, ''),
(19, 'import', 1, 'Consultar histÃ³rico de solicitud'),
(19, 'import', 2, 'Request history'),
(19, 'import', 3, ''),
(20, 'import', 1, 'Reenviar a otros destinatarios'),
(20, 'import', 2, 'Send quote request to others recipients'),
(20, 'import', 3, 'å‘é€æŠ¥ä»·è¯·æ±‚ä»–äººçš„æŽ¥å—è€…'),
(21, 'import', 1, 'Enviar la solicitud a otros destinatarios'),
(21, 'import', 2, 'Send qouotation request to other addresses'),
(21, 'import', 3, ''),
(22, 'import', 1, 'Destinatarios (separados por coma):'),
(22, 'import', 2, 'send mail to (separate mails with comma):'),
(22, 'import', 3, ''),
(23, 'import', 1, 'Eliminar'),
(23, 'import', 2, 'Delete'),
(23, 'import', 3, ''),
(24, 'import', 1, 'Eliminar solicitud de cotizaciÃ³n'),
(24, 'import', 2, 'Delete quote request'),
(24, 'import', 3, 'åˆ é™¤æŠ¥ä»·è¯·æ±‚'),
(25, 'import', 1, 'Â¿EstÃ¡ seguro que desea eliminar la cotizaciÃ³n?'),
(25, 'import', 2, 'Sure to delete this quote request?'),
(25, 'import', 3, 'ä¸€å®šè¦åˆ é™¤æ­¤æŠ¥ä»·è¦æ±‚ï¼Ÿ'),
(26, 'import', 1, 'InformaciÃ³n General de la cotizaciÃ³n de proveedor'),
(26, 'import', 2, 'Supplier Quote general information'),
(26, 'import', 3, 'ä¾›åº”å•†çš„æŠ¥ä»·ä¸€èˆ¬ä¿¡æ¯'),
(27, 'import', 1, 'CÃ³digo de acceso del Proveedor'),
(27, 'import', 2, 'Supplier access code'),
(27, 'import', 3, ''),
(28, 'import', 1, 'Solicitud de CotizaciÃ³n de Cliente Relacionada'),
(28, 'import', 2, 'Client requst related'),
(28, 'import', 3, ''),
(29, 'import', 1, 'Productos a cotizar por el proveedor'),
(29, 'import', 2, 'Products in current quote request'),
(29, 'import', 3, 'äº§å“ç›®å‰æŠ¥ä»·è¯·æ±‚'),
(30, 'import', 1, 'CÃ³digo'),
(30, 'import', 2, 'Code'),
(30, 'import', 3, ''),
(31, 'import', 1, 'Nombre'),
(31, 'import', 2, 'Name'),
(31, 'import', 3, ''),
(32, 'import', 1, 'Plazo de Entrega'),
(32, 'import', 2, 'Delivery'),
(32, 'import', 3, ''),
(33, 'import', 1, 'Cantidad'),
(33, 'import', 2, 'Quantity'),
(33, 'import', 3, ''),
(34, 'import', 1, 'Precio Unitario del Proveedor'),
(34, 'import', 2, 'Supplier&#0039;s Unit price'),
(34, 'import', 3, ''),
(35, 'import', 1, 'Dias'),
(35, 'import', 2, 'Days'),
(35, 'import', 3, ''),
(36, 'import', 1, 'No se ha cotizado'),
(36, 'import', 2, 'Not quoted'),
(36, 'import', 3, ''),
(37, 'import', 1, 'Negociar'),
(37, 'import', 2, 'Negotiate'),
(37, 'import', 3, ''),
(38, 'import', 1, 'Se ha pedido la negociaciÃ³n del item y se ha notificado al proveedor.'),
(38, 'import', 2, 'Negotiation on item requested and supplier notified via email'),
(38, 'import', 3, ''),
(1, '', 1, 'Crear TraducciÃ³n Bulk'),
(1, '', 2, ''),
(1, '', 3, ''),
(2, '', 1, 'A continuaciÃ³n se muestra el formulario de creaciÃ³n de traducciones bulk. Ingrese las traducciones y haga click en &quot;Aceptar&quot; para crear los textos.'),
(2, '', 2, ''),
(2, '', 3, ''),
(51, 'multilang', 1, 'Crear MÃºltples Traducciones '),
(51, 'multilang', 2, 'Create translations &quot;bulk&quot;'),
(51, 'multilang', 3, ''),
(52, 'multilang', 1, 'A continuaciÃ³n se muestra el formulario de creaciÃ³n de traducciones mÃºltiples. Para agregar una nueva fila de traducciones, haga click en &quot;Agregar traducciÃ³n&quot; y una nueva fila aparecerÃ¡. Ingrese las traducciones y haga click en &quot;Aceptar&quot; para crear los textos.'),
(52, 'multilang', 2, 'The following form allows you to create bulk ttranslations. To add more translations, click on &quot;Add trasnlations&quot; and a new row will appear. To save trasnlations, click on &quot;Accept&quot;.'),
(52, 'multilang', 3, ''),
(53, 'multilang', 1, 'Agregar MÃºltiples Traducciones'),
(53, 'multilang', 2, 'Add Translations &quot;Bulk&quot;'),
(53, 'multilang', 3, ''),
(39, 'import', 1, 'Solicitud de CotizaciÃ³n'),
(39, 'import', 2, 'Quote Request'),
(39, 'import', 3, 'æŠ¥ä»·è¯·æ±‚'),
(40, 'import', 1, 'CotizaciÃ³n de Producto'),
(40, 'import', 2, 'Quote request for'),
(40, 'import', 3, 'æŠ¥ä»·è¦æ±‚'),
(41, 'import', 1, 'A continuaciÃ³n podrÃ¡ ingresar los datos de la cotizaciÃ³n del producto'),
(41, 'import', 2, 'In the following form you may quote '),
(41, 'import', 3, ''),
(42, 'import', 1, 'Para guardar el precio y confirmar la cotizaciÃ³n del producto, haga click en &quot;Cotizar Item&quot;. Recuerde que puede modificar los datos del item mientras no haya confirmado la cotizaciÃ³n completa.'),
(42, 'import', 2, 'To save quote and confirm, click on &quot;Quote item&quot;. Remember, that you may change any of the items in the form until you confirm the whole quote.'),
(42, 'import', 3, 'ä¸ºäº†èŠ‚çœæŠ¥ä»·å’Œç¡®è®¤ï¼ŒæŒ‰â€œæŠ¥ä»·é¡¹ç›®â€ ã€‚è¯·è®°ä½ï¼Œæ‚¨å¯èƒ½ä¼šæ”¹å˜çš„ä»»ä½•é¡¹ç›®çš„å½¢å¼ï¼Œç›´åˆ°æ‚¨ç¡®è®¤æ•´ä¸ªç«žæ ‡ã€‚'),
(43, 'import', 1, 'Detalle del producto'),
(43, 'import', 2, 'Product detail'),
(43, 'import', 3, ''),
(44, 'import', 1, 'DescripciÃ³n'),
(44, 'import', 2, 'Description'),
(44, 'import', 3, ''),
(45, 'import', 1, 'InformaciÃ³n de Empaque'),
(45, 'import', 2, 'Packaging Information'),
(45, 'import', 3, ''),
(46, 'import', 1, 'El producto se entrega en'),
(46, 'import', 2, 'Product is delivered'),
(46, 'import', 3, ''),
(47, 'import', 1, 'Empaques Unitarios'),
(47, 'import', 2, 'Unit package'),
(47, 'import', 3, ''),
(48, 'import', 1, 'Bultos'),
(48, 'import', 2, 'Carton'),
(48, 'import', 3, ''),
(49, 'import', 1, 'Dimensiones Unidad:'),
(49, 'import', 2, 'Unit dimentions'),
(49, 'import', 3, ''),
(50, 'import', 1, 'Alto'),
(50, 'import', 2, 'Height'),
(50, 'import', 3, ''),
(51, 'import', 1, 'Largo'),
(51, 'import', 2, 'Lenght'),
(51, 'import', 3, ''),
(52, 'import', 1, 'Ancho'),
(52, 'import', 2, 'Widht'),
(52, 'import', 3, ''),
(53, 'import', 1, 'cm.'),
(53, 'import', 2, 'cm'),
(53, 'import', 3, ''),
(54, 'import', 1, 'Peso Bruto Unidad'),
(54, 'import', 2, 'Unit Gross Weight'),
(54, 'import', 3, ''),
(55, 'import', 1, 'kg.'),
(55, 'import', 2, 'kg.'),
(55, 'import', 3, ''),
(56, 'import', 1, 'Dimensiones Bulto'),
(56, 'import', 2, 'Carton dimentions'),
(56, 'import', 3, ''),
(57, 'import', 1, 'Unidades por Bulto'),
(57, 'import', 2, 'Units per carton'),
(57, 'import', 3, ''),
(58, 'import', 1, 'unidades'),
(58, 'import', 2, 'units'),
(58, 'import', 3, ''),
(59, 'import', 1, 'Peso Bruto por bulto'),
(59, 'import', 2, 'Carton gross weight'),
(59, 'import', 3, ''),
(60, 'import', 1, 'Precio unitario'),
(60, 'import', 2, 'Unit price'),
(60, 'import', 3, ''),
(61, 'import', 1, 'US$/u'),
(61, 'import', 2, 'US$/u'),
(61, 'import', 3, ''),
(62, 'import', 1, 'Entrega'),
(62, 'import', 2, 'Delivery'),
(62, 'import', 3, ''),
(63, 'import', 1, 'Comentarios'),
(63, 'import', 2, 'Comments'),
(63, 'import', 3, ''),
(64, 'import', 1, 'Cotizar Item'),
(64, 'import', 2, 'Quote Item'),
(64, 'import', 3, ''),
(65, 'import', 1, 'Cancelar'),
(65, 'import', 2, 'Cancel'),
(65, 'import', 3, ''),
(66, 'import', 1, 'Usuario'),
(66, 'import', 2, 'User'),
(66, 'import', 3, ''),
(67, 'import', 1, 'Comentario'),
(67, 'import', 2, 'Comment'),
(67, 'import', 3, ''),
(68, 'import', 1, 'Proveedor'),
(68, 'import', 2, 'Supplier'),
(68, 'import', 3, ''),
(69, 'import', 1, 'Historial de comentarios'),
(69, 'import', 2, 'Comments history'),
(69, 'import', 3, ''),
(70, 'import', 1, 'Agregar Comentario'),
(70, 'import', 2, 'Add comment'),
(70, 'import', 3, ''),
(71, 'import', 1, 'A continuaciÃ³n podrÃ¡ agregar un comentario a esta cotizaciÃ³n.'),
(71, 'import', 2, 'In the following form you may leave a comment about this item quote.'),
(71, 'import', 3, 'åœ¨ä¸‹é¢çš„è¡¨æ ¼ä½ å¯ä»¥å‘è¡¨è¯„è®ºå…³äºŽè¿™ä¸ªé¡¹ç›®çš„ç«žæ ‡'),
(11, 'common', 1, 'EspaÃ±ol'),
(11, 'common', 2, 'English'),
(11, 'common', 3, 'ä¸­æ–‡'),
(72, 'import', 1, 'Nueva'),
(72, 'import', 2, 'New'),
(72, 'import', 3, 'æ–°çš„'),
(73, 'import', 1, 'CotizaciÃ³n solicitada'),
(73, 'import', 2, 'Quote Requested'),
(73, 'import', 3, 'æŠ¥ä»·è¦æ±‚'),
(74, 'import', 1, 'Aceptada'),
(74, 'import', 2, 'Accepted'),
(74, 'import', 3, 'æŽ¥å—'),
(75, 'import', 1, 'Esperando por precio'),
(75, 'import', 2, 'Waiting For Pricing'),
(75, 'import', 3, 'ç­‰å¾…å®šä»·'),
(76, 'import', 1, 'Cotizada'),
(76, 'import', 2, 'Quoted'),
(76, 'import', 3, 'å¼•ç”¨'),
(77, 'import', 1, 'Cotizada parcialmente'),
(77, 'import', 2, 'Partially Quoted'),
(77, 'import', 3, 'éƒ¨åˆ†æŠ¥ä»·'),
(78, 'import', 1, 'En negociaciÃ³n'),
(78, 'import', 2, 'Feedback'),
(78, 'import', 3, 'æ­£åœ¨è°ˆåˆ¤'),
(79, 'import', 1, 'Estimado Proveedor'),
(79, 'import', 2, 'Dear Supplier'),
(79, 'import', 3, 'å°Šæ•¬çš„ä¾›åº”å•†'),
(80, 'import', 1, 'Tenemos una solicitud de cotizaciÃ³n. Para responderla, por favor haga click '),
(80, 'import', 2, 'We request a quote. To answer it, please click'),
(80, 'import', 3, 'æˆ‘ä»¬è¦æ±‚æŠ¥ä»·ã€‚ä¸ºå›žç­”è¿™ä¸€é—®é¢˜ï¼Œè¯·ç‚¹å‡»'),
(81, 'import', 1, 'Si el link de arriba no funciona pude ingresar copiando este link y pegarlo en el navegador'),
(81, 'import', 2, 'If the above link is not working I could enter by copying and pasting this link into your browser'),
(81, 'import', 3, 'å¦‚æžœä¸Šé¢çš„é“¾æŽ¥ä¸å·¥ä½œæˆ‘å¯ä»¥è¾“å…¥å¤åˆ¶å¹¶ç²˜è´´è¯¥é“¾æŽ¥åˆ°æ‚¨çš„æµè§ˆå™¨'),
(82, 'import', 1, 'aquÃ­'),
(82, 'import', 2, 'here'),
(82, 'import', 3, 'è¿™é‡Œ'),
(83, 'import', 1, 'Solicitud de CotizaciÃ³n'),
(83, 'import', 2, 'Quote Request'),
(83, 'import', 3, 'æŠ¥ä»·è¯·æ±‚'),
(84, 'import', 1, 'Agregando producto'),
(84, 'import', 2, 'Adding item'),
(84, 'import', 3, 'æ·»åŠ äº§å“'),
(85, 'import', 1, 'buscando'),
(85, 'import', 2, 'searching'),
(85, 'import', 3, 'æœç´¢'),
(86, 'import', 1, 'procesando, cargando valores por default de incoterm y puerto para el proveedor'),
(86, 'import', 2, 'processing, loading default values for Incoterm and port for the supplier'),
(86, 'import', 3, 'åŠ å·¥ï¼Œè½½å…¥ä¸­é»˜è®¤å€¼æœ¯è¯­å’Œæ¸¯å£çš„ä¾›åº”å•†'),
(87, 'import', 1, 'eliminando producto'),
(87, 'import', 2, 'removing item'),
(87, 'import', 3, 'åˆ é™¤é¡¹ç›®'),
(88, 'import', 1, 'cargando ordenes'),
(88, 'import', 2, 'loading orders'),
(88, 'import', 3, 'è½½å…¥ä¸­è®¢å•'),
(89, 'import', 1, 'En proceso'),
(89, 'import', 2, 'In Progress'),
(89, 'import', 3, '');

-- --------------------------------------------------------

--
-- Table structure for table `security_action`
--

DROP TABLE IF EXISTS `security_action`;
CREATE TABLE IF NOT EXISTS `security_action` (
  `action` varchar(100) collate latin1_general_cs NOT NULL COMMENT 'Action pagina',
  `module` varchar(100) collate latin1_general_cs default NULL COMMENT 'Modulo',
  `section` varchar(100) collate latin1_general_cs default NULL COMMENT 'Seccion',
  `access` int(11) default NULL COMMENT 'El acceso a ese action',
  `accessAffiliateUser` int(11) default NULL COMMENT 'El acceso a ese action para los usuarios por afiliados',
  `accessRegistrationUser` int(11) default NULL COMMENT 'El acceso a ese action para los usuarios por registracion',
  `active` int(11) default NULL COMMENT 'Si el action esta activo o no',
  `pair` varchar(100) collate latin1_general_cs default NULL COMMENT 'Par del Action',
  `noCheckLogin` tinyint(4) default '0' COMMENT 'Si no se chequea login ese action',
  PRIMARY KEY  (`action`),
  KEY `security_action_FI_1` (`module`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Actions del sistema';

--
-- Dumping data for table `security_action`
--

INSERT INTO `security_action` (`action`, `module`, `section`, `access`, `accessAffiliateUser`, `accessRegistrationUser`, `active`, `pair`, `noCheckLogin`) VALUES
('backupRestoreFromFile', 'backup', '', 3, 0, 0, 1, 'Array', 0),
('backupDownload', 'backup', '', 3, 0, 0, 1, 'Array', 0),
('backupCreate', 'backup', '', 3, 0, 0, 1, 'Array', 0),
('backupCreateToFile', 'backup', '', 3, 0, 0, 1, 'Array', 0),
('backupList', 'backup', '', 3, 0, 0, 1, 'Array', 0),
('backupRestore', 'backup', '', 3, 0, 0, 1, 'Array', 0),
('backupDelete', 'backup', '', 3, 0, 0, 1, 'Array', 0);

-- --------------------------------------------------------

--
-- Table structure for table `security_actionLabel`
--

DROP TABLE IF EXISTS `security_actionLabel`;
CREATE TABLE IF NOT EXISTS `security_actionLabel` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Id label security',
  `action` varchar(100) collate latin1_general_cs NOT NULL COMMENT 'Action pagina',
  `language` varchar(100) collate latin1_general_cs default NULL COMMENT 'Idioma de la etiqueta',
  `label` varchar(100) collate latin1_general_cs default NULL COMMENT 'Etiqueta',
  PRIMARY KEY  (`id`,`action`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='etiquetas de actions de seguridad' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `security_actionLabel`
--


-- --------------------------------------------------------

--
-- Table structure for table `security_module`
--

DROP TABLE IF EXISTS `security_module`;
CREATE TABLE IF NOT EXISTS `security_module` (
  `module` varchar(100) collate latin1_general_cs NOT NULL COMMENT 'Modulo',
  `access` int(11) default NULL COMMENT 'El acceso a ese modulo',
  `accessAffiliateUser` int(11) default NULL COMMENT 'El acceso a ese modulo para los usuarios por afiliados',
  `accessRegistrationUser` int(11) default NULL COMMENT 'El acceso a ese modulo para los usuarios por registracion',
  PRIMARY KEY  (`module`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Modulos del sistema';

--
-- Dumping data for table `security_module`
--

INSERT INTO `security_module` (`module`, `access`, `accessAffiliateUser`, `accessRegistrationUser`) VALUES
('backup', 3, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `usersByAffiliate_group`
--

DROP TABLE IF EXISTS `usersByAffiliate_group`;
CREATE TABLE IF NOT EXISTS `usersByAffiliate_group` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Group ID',
  `name` varchar(255) collate latin1_general_cs NOT NULL COMMENT 'Group Name',
  `created` datetime NOT NULL COMMENT 'Creation date for',
  `updated` datetime NOT NULL COMMENT 'Last update date',
  `bitLevel` int(11) default NULL COMMENT 'Nivel',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `usersByAffiliate_group_U_1` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Groups' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `usersByAffiliate_group`
--


-- --------------------------------------------------------

--
-- Table structure for table `usersByAffiliate_groupCategory`
--

DROP TABLE IF EXISTS `usersByAffiliate_groupCategory`;
CREATE TABLE IF NOT EXISTS `usersByAffiliate_groupCategory` (
  `groupId` int(11) NOT NULL COMMENT 'Group ID',
  `categoryId` int(11) NOT NULL COMMENT 'Category ID',
  PRIMARY KEY  (`groupId`,`categoryId`),
  KEY `usersByAffiliate_groupCategory_ibfk_2` (`categoryId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Groups / Categories';

--
-- Dumping data for table `usersByAffiliate_groupCategory`
--


-- --------------------------------------------------------

--
-- Table structure for table `usersByAffiliate_level`
--

DROP TABLE IF EXISTS `usersByAffiliate_level`;
CREATE TABLE IF NOT EXISTS `usersByAffiliate_level` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Level ID',
  `name` varchar(255) collate latin1_general_cs NOT NULL COMMENT 'Level Name',
  `bitLevel` int(11) default NULL COMMENT 'Bit del nivel',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `usersByAffiliate_level_U_1` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Levels' AUTO_INCREMENT=1 ;

--
-- Dumping data for table `usersByAffiliate_level`
--


-- --------------------------------------------------------

--
-- Table structure for table `usersByAffiliate_user`
--

DROP TABLE IF EXISTS `usersByAffiliate_user`;
CREATE TABLE IF NOT EXISTS `usersByAffiliate_user` (
  `id` int(11) NOT NULL auto_increment COMMENT 'User Id',
  `affiliateId` int(11) NOT NULL COMMENT 'Id afiliado',
  `username` varchar(255) collate latin1_general_cs NOT NULL COMMENT 'username',
  `password` varchar(255) collate latin1_general_cs NOT NULL COMMENT 'password',
  `active` int(11) NOT NULL COMMENT 'Is user active?',
  `created` datetime NOT NULL COMMENT 'Creation date for',
  `updated` datetime NOT NULL COMMENT 'Last update date',
  `levelId` int(11) default NULL COMMENT 'User Level',
  `lastLogin` datetime default NULL COMMENT 'Fecha del ultimo login del usuario',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `usersByAffiliate_user_U_1` (`username`),
  KEY `usersByAffiliate_user_ibfk_2` (`levelId`),
  KEY `usersByAffiliate_user_ibfk_3` (`affiliateId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Usuarios de afiliado' AUTO_INCREMENT=3 ;

--
-- Dumping data for table `usersByAffiliate_user`
--

INSERT INTO `usersByAffiliate_user` (`id`, `affiliateId`, `username`, `password`, `active`, `created`, `updated`, `levelId`, `lastLogin`) VALUES
(1, 2, 'juan', '9779c1d0c2d241a3e3a709f44af98ef1', 1, '2007-04-24 15:06:03', '2007-04-24 15:06:03', 0, '2007-05-30 14:33:44'),
(2, 1, 'makro', 'b0672b93fc29da67213f703dec462a5c', 1, '2007-06-08 10:48:10', '2007-06-08 10:48:10', 1, '2007-06-13 12:42:06');

-- --------------------------------------------------------

--
-- Table structure for table `usersByAffiliate_userGroup`
--

DROP TABLE IF EXISTS `usersByAffiliate_userGroup`;
CREATE TABLE IF NOT EXISTS `usersByAffiliate_userGroup` (
  `userId` int(11) NOT NULL COMMENT 'Group ID',
  `groupId` int(11) NOT NULL COMMENT 'Group ID',
  PRIMARY KEY  (`userId`,`groupId`),
  KEY `usersByAffiliate_userGroup_ibfk_2` (`groupId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Users / Groups';

--
-- Dumping data for table `usersByAffiliate_userGroup`
--


-- --------------------------------------------------------

--
-- Table structure for table `usersByAffiliate_userInfo`
--

DROP TABLE IF EXISTS `usersByAffiliate_userInfo`;
CREATE TABLE IF NOT EXISTS `usersByAffiliate_userInfo` (
  `userId` int(11) NOT NULL COMMENT 'User Id',
  `name` varchar(255) collate latin1_general_cs default NULL COMMENT 'name',
  `surname` varchar(255) collate latin1_general_cs default NULL COMMENT 'surname',
  `mailAddress` varchar(255) collate latin1_general_cs NOT NULL COMMENT 'Email',
  PRIMARY KEY  (`userId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Information about users by affiliates';

--
-- Dumping data for table `usersByAffiliate_userInfo`
--

INSERT INTO `usersByAffiliate_userInfo` (`userId`, `name`, `surname`, `mailAddress`) VALUES
(1, 'Juan', 'Perez', 'jp@gmail.com'),
(2, 'Luis', 'Makro', 'lmakro@yahoo.com');

-- --------------------------------------------------------

--
-- Table structure for table `users_group`
--

DROP TABLE IF EXISTS `users_group`;
CREATE TABLE IF NOT EXISTS `users_group` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Group ID',
  `name` varchar(255) collate latin1_general_cs NOT NULL COMMENT 'Group Name',
  `created` datetime NOT NULL COMMENT 'Creation date for',
  `updated` datetime NOT NULL COMMENT 'Last update date',
  `bitLevel` int(11) default NULL COMMENT 'Nivel',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `users_group_U_1` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Groups' AUTO_INCREMENT=3 ;

--
-- Dumping data for table `users_group`
--

INSERT INTO `users_group` (`id`, `name`, `created`, `updated`, `bitLevel`) VALUES
(1, 'supervisor', '2001-01-01 00:00:00', '2001-01-01 00:00:00', NULL),
(2, 'admin', '2001-01-01 00:00:00', '2001-01-01 00:00:00', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users_groupCategory`
--

DROP TABLE IF EXISTS `users_groupCategory`;
CREATE TABLE IF NOT EXISTS `users_groupCategory` (
  `groupId` int(11) NOT NULL COMMENT 'Group ID',
  `categoryId` int(11) NOT NULL COMMENT 'Category ID',
  PRIMARY KEY  (`groupId`,`categoryId`),
  KEY `users_groupCategory_FI_2` (`categoryId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Groups / Categories';

--
-- Dumping data for table `users_groupCategory`
--


-- --------------------------------------------------------

--
-- Table structure for table `users_level`
--

DROP TABLE IF EXISTS `users_level`;
CREATE TABLE IF NOT EXISTS `users_level` (
  `id` int(11) NOT NULL auto_increment COMMENT 'Level ID',
  `name` varchar(255) collate latin1_general_cs NOT NULL COMMENT 'Level Name',
  `bitLevel` int(11) default NULL COMMENT 'Bit del nivel',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `users_level_U_1` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Levels' AUTO_INCREMENT=6 ;

--
-- Dumping data for table `users_level`
--

INSERT INTO `users_level` (`id`, `name`, `bitLevel`) VALUES
(1, 'Supervisor', 1),
(2, 'Administrador', 2),
(3, 'Usuario', 4),
(4, 'Presidente', 8),
(5, 'Usuario.cn', 16);

-- --------------------------------------------------------

--
-- Table structure for table `users_user`
--

DROP TABLE IF EXISTS `users_user`;
CREATE TABLE IF NOT EXISTS `users_user` (
  `id` int(11) NOT NULL auto_increment COMMENT 'User Id',
  `username` varchar(255) collate latin1_general_cs NOT NULL COMMENT 'username',
  `password` varchar(255) collate latin1_general_cs NOT NULL COMMENT 'password',
  `active` tinyint(4) NOT NULL COMMENT 'Is user active?',
  `created` datetime NOT NULL COMMENT 'Creation date for',
  `updated` datetime NOT NULL COMMENT 'Last update date',
  `levelId` int(11) default NULL COMMENT 'User Level',
  `lastLogin` datetime default NULL COMMENT 'Fecha del ultimo login del usuario',
  `timezone` varchar(100) collate latin1_general_cs default NULL COMMENT 'Timezone GMT del usuario',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `users_user_U_1` (`username`),
  KEY `users_user_FI_1` (`levelId`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Users' AUTO_INCREMENT=3 ;

--
-- Dumping data for table `users_user`
--

INSERT INTO `users_user` (`id`, `username`, `password`, `active`, `created`, `updated`, `levelId`, `lastLogin`, `timezone`) VALUES
(1, 'supervisor', 'd40a4afe38b91cf04bdecc71bf4db659', 1, '2001-01-01 00:00:00', '2001-01-01 00:00:00', 1, '2009-05-08 21:21:44', '-4.5'),
(2, 'admin', '45c48d97153f26e17d101be744368331', 1, '2001-01-01 00:00:00', '2001-01-01 00:00:00', 2, '2009-04-17 17:18:08', '-3');

-- --------------------------------------------------------

--
-- Table structure for table `users_userGroup`
--

DROP TABLE IF EXISTS `users_userGroup`;
CREATE TABLE IF NOT EXISTS `users_userGroup` (
  `userId` int(11) NOT NULL COMMENT 'Group ID',
  `groupId` int(11) NOT NULL COMMENT 'Group ID',
  PRIMARY KEY  (`userId`,`groupId`),
  KEY `users_userGroup_FI_2` (`groupId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Users / Groups';

--
-- Dumping data for table `users_userGroup`
--

INSERT INTO `users_userGroup` (`userId`, `groupId`) VALUES
(1, 1),
(1, 2),
(2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `users_userInfo`
--

DROP TABLE IF EXISTS `users_userInfo`;
CREATE TABLE IF NOT EXISTS `users_userInfo` (
  `userId` int(11) NOT NULL COMMENT 'User Id',
  `name` varchar(255) collate latin1_general_cs default NULL COMMENT 'name',
  `surname` varchar(255) collate latin1_general_cs default NULL COMMENT 'surname',
  `mailAddress` varchar(255) collate latin1_general_cs default NULL COMMENT 'Email',
  PRIMARY KEY  (`userId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_cs COMMENT='Information about users';

--
-- Dumping data for table `users_userInfo`
--

INSERT INTO `users_userInfo` (`userId`, `name`, `surname`, `mailAddress`) VALUES
(1, 'Supervisor', 'Supervisor', ''),
(2, 'Admin', 'Admin', '');
